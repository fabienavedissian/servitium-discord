import * as _angular_core from '@angular/core';
import { InjectionToken, PipeTransform, OnChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { SelectOption } from '@servitium/ui';

type ChannelTier = 'free' | 'agent';
interface RateLimitInfo {
    canRename: boolean;
    recentRenames: number;
    maxRenames: number;
    nextAvailableAt?: string;
    remainingMinutes?: number;
}
interface ServitiumInfoOptions {
    customInfo?: string;
}
interface BuildingAlertsOptions {
    mode: 'violations' | 'count';
    threshold?: number;
    useServerLimit: boolean;
}
interface BuildingLeaderboardOptions {
    threshold: number;
}
interface PvpStatsOptions {
    showDeaths: boolean;
    showTeamkills: boolean;
    showKDA: boolean;
}
interface RaidProtectionOptions {
    filter: 'today' | 'today-yesterday' | 'this-week' | 'all-actives' | 'all-actives-yesterday';
}
interface KillfeedOptions {
    showWeapon: boolean;
}
interface ServerStatusOptions {
    displayServerName?: boolean;
    hidePlayerCount?: boolean;
    customDisplayName?: string;
}
interface ChannelOptions {
    buildingAlerts?: BuildingAlertsOptions;
    buildingLeaderboard?: BuildingLeaderboardOptions;
    pvpStats?: PvpStatsOptions;
    guildPvpStats?: PvpStatsOptions;
    raidProtection?: RaidProtectionOptions;
    serverStatus?: ServerStatusOptions;
    killfeed?: KillfeedOptions;
    servitiumInfo?: ServitiumInfoOptions;
}
interface DiscordChannelConfig {
    enabled: boolean;
    channelId?: string;
    customName: string;
    visibility: 'public' | 'admin-only';
    module: string;
    categoryKey?: string;
    tier?: ChannelTier;
    options?: ChannelOptions;
    rateLimitInfo?: RateLimitInfo;
}
interface ChannelCategory {
    key: string;
    name: string;
    order: number;
    showServerName?: boolean;
    categoryChannelId?: string;
}
interface DiscordConfig {
    clientId: string;
    guildId: string;
    discordServerId?: string;
    serverName: string;
    enabled: boolean;
    channels: Record<string, DiscordChannelConfig>;
    categories?: ChannelCategory[];
    categoryPrefix?: string;
    permissions: {
        createChannels: boolean;
        manageRoles: boolean;
        manageMessages: boolean;
    };
    settings: {
        autoCreateChannels: boolean;
        defaultChannelNames: boolean;
        defaultCategoryName: string;
    };
    tickets?: {
        staffRoles: string[];
        adminRoles: string[];
        categoryId?: string;
    };
    welcomeChannelId?: string | null;
    welcomeChannelName?: string | null;
    welcomeImageUrl?: string | null;
    welcomeThumbnailUrl?: string | null;
    welcomeTitle?: string | null;
    welcomeDescription?: string | null;
    welcomeEnabled?: boolean;
    welcomeColor?: string | null;
    welcomePing?: boolean;
    welcomeBannerEnabled?: boolean;
    welcomeBannerColor?: string | null;
    goodbyeChannelId?: string | null;
    goodbyeChannelName?: string | null;
    goodbyeImageUrl?: string | null;
    goodbyeThumbnailUrl?: string | null;
    goodbyeTitle?: string | null;
    goodbyeDescription?: string | null;
    goodbyeEnabled?: boolean;
    goodbyeColor?: string | null;
    goodbyeBannerEnabled?: boolean;
    goodbyeBannerColor?: string | null;
    voiceHubs?: VoiceHub[];
    raidProtectionRebuildGiftIds?: string[];
}
type GreetingMode = 'welcome' | 'goodbye';
/** Seed for the greeting editor — both welcome and goodbye share this shape. */
interface GreetingSeed {
    enabled: boolean;
    channelId: string | null;
    channelName: string | null;
    title: string;
    description: string;
    imageUrl: string;
    thumbnailUrl: string;
    color: string;
    ping: boolean;
    bannerEnabled: boolean;
    bannerColor: string;
}
interface GreetingSettingsPayload {
    enabled?: boolean;
    title?: string | null;
    description?: string | null;
    imageUrl?: string | null;
    thumbnailUrl?: string | null;
    color?: string | null;
    ping?: boolean;
    bannerEnabled?: boolean;
    bannerColor?: string | null;
}
interface DiscordChannel {
    id: string;
    name: string;
    type: number;
}
interface DiscordRole {
    id: string;
    name: string;
    color: number;
    position: number;
    managed: boolean;
}
interface VoiceHub {
    channelId: string;
    namePattern: string;
    allowedRoleIds: string[];
}
interface DiscordGuildSpace {
    serverId: string;
    gameType: string;
    roleId: string;
    roleName: string;
}
type DiscordGameAccessMode = 'LEGACY' | 'ADVANCED_GAME_SERVER';
interface DiscordGuildConfigAdvanced {
    discordServerId: string;
    gameAccessMode: DiscordGameAccessMode;
    selectionChannelId?: string | null;
    selectionMessageId?: string | null;
    spaces: DiscordGuildSpace[];
}
interface LevelReward {
    level: number;
    roleId: string;
}
interface LevelingConfig {
    enabled: boolean;
    minMessageLength: number;
    ignoredChannelIds: string[];
    rewards: LevelReward[];
}
interface LevelEntry {
    userId: string;
    xp: number;
    level: number;
}
interface ReactionRoleMapping {
    customId: string;
    roleId: string;
    label: string;
}
interface ReactionPanel {
    _id: string;
    guildId: string;
    channelId: string;
    messageId: string | null;
    title: string;
    description: string;
    mappings: ReactionRoleMapping[];
}
interface CreateReactionPanelPayload {
    channelId: string;
    title: string;
    description?: string;
    mappings: Array<{
        roleId: string;
        label: string;
    }>;
}
interface AutomodConfig {
    enabled: boolean;
    linkFilter: boolean;
    spamFilter: boolean;
    mentionSpam: boolean;
    ruleIds: string[];
}
interface StatsChannelsConfig {
    enabled: boolean;
    memberCountChannelId: string | null;
    onlineCountChannelId: string | null;
    memberCountTemplate: string;
    onlineCountTemplate: string;
}
interface ReactionRolesFeature {
    enabled: boolean;
}
interface GiveawaysFeature {
    enabled: boolean;
}
interface DiscordGiveaway {
    _id: string;
    guildId: string;
    channelId: string;
    messageId: string | null;
    prize: string;
    endAt: string;
    winnerCount: number;
    entrantUserIds: string[];
    ended: boolean;
    hostUserId: string;
    winnerUserIds: string[];
}
interface CreateGiveawayPayload {
    channelId: string;
    prize: string;
    durationMs: number;
    winnerCount?: number;
    hostUserId: string;
}

/**
 * Data contract for the Discord management UI. The feature components depend on
 * this port, never a concrete API client, so the same components run on
 * center.servitium.org (account auth, game Server context) and
 * discord.servitium.org (Discord OAuth, guild-only context). Each app binds the
 * token to its own adapter. `clientId` is the context id (a game Server id on
 * Center; a guild-scoped id on the standalone app).
 *
 * The "agent" methods at the bottom are paid game-server features, only wired
 * where an agent exists.
 */
interface DiscordDataPort {
    getDiscordConfig(clientId: string): Observable<DiscordConfig>;
    createOrUpdateConfig(clientId: string, config: Partial<DiscordConfig>): Observable<{
        message: string;
    }>;
    enableDiscord(clientId: string): Observable<{
        message: string;
    }>;
    disableDiscord(clientId: string): Observable<{
        message: string;
    }>;
    getInviteUrl(serverId: string): Observable<{
        inviteUrl: string;
    }>;
    getAvailableGuilds(clientId: string): Observable<{
        guilds: Array<{
            guildId: string;
            guildName: string;
            serverName: string;
            serverId: string;
        }>;
    }>;
    linkToExistingGuild(clientId: string, guildId: string): Observable<{
        message: string;
    }>;
    unlinkDiscord(clientId: string): Observable<{
        message: string;
    }>;
    getDiscordRoles(clientId: string): Observable<{
        roles: DiscordRole[];
    }>;
    getAvailableChannels(clientId: string): Observable<DiscordChannel[]>;
    configureChannel(clientId: string, channelType: string, config: Partial<DiscordChannelConfig>): Observable<{
        message: string;
    }>;
    renameChannel(clientId: string, channelType: string, newName: string): Observable<{
        message: string;
    }>;
    updateChannelVisibility(clientId: string, channelType: string, visibility: 'public' | 'admin-only'): Observable<{
        message: string;
    }>;
    updateChannelOptions(clientId: string, channelType: string, options: Partial<ChannelOptions>): Observable<{
        message: string;
    }>;
    resyncChannels(clientId: string): Observable<{
        resynced: string[];
        failed: Array<{
            channel: string;
            error: string;
        }>;
    }>;
    saveCategories(clientId: string, body: {
        categories: Array<{
            key: string;
            name: string;
            showServerName?: boolean;
        }>;
        assignments: Record<string, string | null>;
        categoryPrefix?: string;
    }): Observable<{
        applied: number;
        failed: Array<{
            channel: string;
            error: string;
        }>;
    }>;
    updateWelcomeChannel(clientId: string, channelId: string | null): Observable<{
        message: string;
    }>;
    updateWelcomeSettings(clientId: string, settings: {
        imageUrl?: string | null;
        thumbnailUrl?: string | null;
        title?: string | null;
        description?: string | null;
    }): Observable<{
        message: string;
    }>;
    updateGreetingChannel(clientId: string, mode: GreetingMode, channelId: string | null): Observable<{
        message: string;
    }>;
    updateGreetingSettings(clientId: string, mode: GreetingMode, settings: GreetingSettingsPayload): Observable<{
        message: string;
    }>;
    sendGreetingTest(clientId: string, mode: GreetingMode, sampleName?: string): Observable<{
        message: string;
    }>;
    createVoiceHub(clientId: string, body: {
        namePattern?: string;
        allowedRoleIds?: string[];
    }): Observable<{
        message: string;
        hub: VoiceHub;
    }>;
    updateVoiceHub(clientId: string, channelId: string, body: {
        namePattern?: string;
        allowedRoleIds?: string[];
    }): Observable<{
        message: string;
    }>;
    deleteVoiceHub(clientId: string, channelId: string): Observable<{
        message: string;
    }>;
    getAdvancedGuildConfig(clientId: string): Observable<{
        success: boolean;
        config: DiscordGuildConfigAdvanced | null;
    }>;
    updateAdvancedGuildConfig(clientId: string, gameAccessMode: DiscordGameAccessMode): Observable<{
        success: boolean;
        guildConfig: DiscordGuildConfigAdvanced;
    }>;
    getGuildLinkedServers(clientId: string): Observable<{
        servers: Array<{
            serverId: string;
            serverName: string;
            gameType: string;
            isInSpaces: boolean;
            roleId?: string;
            roleName?: string;
        }>;
    }>;
    createGameServerRoles(clientId: string, serverIds?: string[]): Observable<{
        success: boolean;
        guildConfig: DiscordGuildConfigAdvanced;
    }>;
    setupSelectionPanel(clientId: string): Observable<{
        success: boolean;
        guildConfig: DiscordGuildConfigAdvanced;
    }>;
    getLevelingConfig(clientId: string): Observable<LevelingConfig>;
    updateLevelingConfig(clientId: string, config: Partial<LevelingConfig>): Observable<{
        message: string;
    }>;
    getLevelingLeaderboard(clientId: string): Observable<LevelEntry[]>;
    getReactionRolesFeature(clientId: string): Observable<ReactionRolesFeature>;
    updateReactionRolesFeature(clientId: string, payload: Partial<ReactionRolesFeature>): Observable<{
        message: string;
    }>;
    getReactionPanels(clientId: string): Observable<ReactionPanel[]>;
    createReactionPanel(clientId: string, payload: CreateReactionPanelPayload): Observable<{
        message: string;
        panel: ReactionPanel;
    }>;
    deleteReactionPanel(clientId: string, panelId: string): Observable<{
        message: string;
    }>;
    getAutomodConfig(clientId: string): Observable<AutomodConfig>;
    updateAutomodConfig(clientId: string, config: Partial<AutomodConfig>): Observable<{
        message: string;
    }>;
    getStatsChannels(clientId: string): Observable<StatsChannelsConfig>;
    updateStatsChannels(clientId: string, config: Partial<StatsChannelsConfig>): Observable<{
        message: string;
    }>;
    getGiveawaysFeature(clientId: string): Observable<GiveawaysFeature>;
    updateGiveawaysFeature(clientId: string, payload: Partial<GiveawaysFeature>): Observable<{
        message: string;
    }>;
    getGiveaways(clientId: string): Observable<DiscordGiveaway[]>;
    createGiveaway(clientId: string, payload: CreateGiveawayPayload): Observable<{
        message: string;
        giveaway: DiscordGiveaway;
    }>;
    deleteGiveaway(clientId: string, giveawayId: string): Observable<{
        message: string;
    }>;
    refreshServerInfo(clientId: string): Observable<{
        message: string;
    }>;
    sendPvPStats(clientId: string): Observable<{
        message: string;
    }>;
    sendGuildPvPStats(clientId: string): Observable<{
        message: string;
    }>;
    sendBuildingLeaderboard(clientId: string): Observable<{
        message: string;
    }>;
    triggerBuildingAlerts(clientId: string): Observable<{
        message: string;
    }>;
}
declare const DISCORD_DATA_PORT: InjectionToken<DiscordDataPort>;

/**
 * i18n contract for the Discord feature components. Each app binds it to its own
 * translation service so the components carry no app-specific i18n dependency.
 */
interface TranslatePort {
    translate(key: string, params?: Record<string, any>): string;
}
declare const TRANSLATE_PORT: InjectionToken<TranslatePort>;
/** `| localize` resolved through TRANSLATE_PORT. Impure so it follows language changes. */
declare class LocalizePipe implements PipeTransform {
    private port;
    transform(key: string, params?: {
        [key: string]: any;
    }): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LocalizePipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<LocalizePipe, "localize", true>;
}

/**
 * Toast/notification contract for the Discord feature components. Each app binds
 * it to its own toast service.
 */
interface NotificationPort {
    success(title: string, message: string): void;
    error(title: string, message: string): void;
}
declare const NOTIFICATION_PORT: InjectionToken<NotificationPort>;

interface WelcomeSeed {
    channelId: string | null;
    imageUrl: string;
    thumbnailUrl: string;
    title: string;
    description: string;
}
/**
 * "Welcome message" feature — fully app-agnostic: depends only on
 * DISCORD_DATA_PORT + TRANSLATE_PORT + NOTIFICATION_PORT + inputs.
 */
declare class DiscordWelcomeComponent {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    canEdit: boolean;
    availableChannels: DiscordChannel[];
    isLoadingChannels: boolean;
    serverName: string;
    welcomeChannelName: string | null;
    set welcome(v: WelcomeSeed | null);
    private _channelId;
    private _enabled;
    private _selectedChannel;
    private _imageUrl;
    private _thumbnailUrl;
    private _title;
    private _description;
    private _saveTimer;
    enabled: _angular_core.Signal<boolean>;
    selectedChannel: _angular_core.Signal<string>;
    imageUrl: _angular_core.Signal<string>;
    thumbnailUrl: _angular_core.Signal<string>;
    title: _angular_core.Signal<string>;
    description: _angular_core.Signal<string>;
    channelOptions(): SelectOption[];
    previewTitle: _angular_core.Signal<string>;
    previewDescription: _angular_core.Signal<string>;
    onToggle(enabled: boolean): void;
    onChannelSelect(option: SelectOption | null): void;
    private onChannelChange;
    channelMissingFromList(): boolean;
    onTitleInput(e: Event): void;
    onDescriptionInput(e: Event): void;
    onThumbnailInput(e: Event): void;
    onImageInput(e: Event): void;
    private scheduleSave;
    private saveSettings;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordWelcomeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordWelcomeComponent, "svt-discord-welcome", never, { "clientId": { "alias": "clientId"; "required": false; }; "canEdit": { "alias": "canEdit"; "required": false; }; "availableChannels": { "alias": "availableChannels"; "required": false; }; "isLoadingChannels": { "alias": "isLoadingChannels"; "required": false; }; "serverName": { "alias": "serverName"; "required": false; }; "welcomeChannelName": { "alias": "welcomeChannelName"; "required": false; }; "welcome": { "alias": "welcome"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Greeting editor for BOTH the welcome (join) and goodbye (leave) messages —
 * driven by the `mode` input. App-agnostic: depends only on the three ports +
 * inputs. Variables, accent color, ping (welcome only), auto banner, live
 * preview and a "send test" action.
 */
declare class DiscordGreetingComponent {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    canEdit: boolean;
    mode: GreetingMode;
    availableChannels: DiscordChannel[];
    isLoadingChannels: boolean;
    serverName: string;
    set greeting(v: GreetingSeed | null);
    variables: string[];
    private _enabled;
    private _channelId;
    private _selectedChannel;
    private _title;
    private _description;
    private _imageUrl;
    private _thumbnailUrl;
    private _color;
    private _ping;
    private _bannerEnabled;
    private _bannerColor;
    private _saveTimer;
    isWelcome: _angular_core.Signal<boolean>;
    enabled: _angular_core.Signal<boolean>;
    selectedChannel: _angular_core.Signal<string>;
    title: _angular_core.Signal<string>;
    description: _angular_core.Signal<string>;
    imageUrl: _angular_core.Signal<string>;
    thumbnailUrl: _angular_core.Signal<string>;
    color: _angular_core.Signal<string>;
    ping: _angular_core.Signal<boolean>;
    bannerEnabled: _angular_core.Signal<boolean>;
    bannerColor: _angular_core.Signal<string>;
    private modeCap;
    cardTitleKey: _angular_core.Signal<string>;
    cardDescKey: _angular_core.Signal<string>;
    enableLabelKey: _angular_core.Signal<string>;
    channelOptions(): SelectOption[];
    previewTitle: _angular_core.Signal<string>;
    previewDescription: _angular_core.Signal<string>;
    previewSubtitle: _angular_core.Signal<"Member #1,234" | "We'll miss you">;
    private substitute;
    channelMissingFromList(): boolean;
    onToggle(enabled: boolean): void;
    onChannelSelect(option: SelectOption | null): void;
    insertVariable(v: string): void;
    onTitleInput(e: Event): void;
    onDescriptionInput(e: Event): void;
    onThumbnailInput(e: Event): void;
    onImageInput(e: Event): void;
    onColorInput(e: Event): void;
    onBannerColorInput(e: Event): void;
    onPingToggle(ping: boolean): void;
    onBannerToggle(bannerEnabled: boolean): void;
    sendTest(): void;
    private scheduleSave;
    private saveSettings;
    private saved;
    private failed;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordGreetingComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordGreetingComponent, "svt-discord-greeting", never, { "clientId": { "alias": "clientId"; "required": false; }; "canEdit": { "alias": "canEdit"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "availableChannels": { "alias": "availableChannels"; "required": false; }; "isLoadingChannels": { "alias": "isLoadingChannels"; "required": false; }; "serverName": { "alias": "serverName"; "required": false; }; "greeting": { "alias": "greeting"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * "Join to Create" voice hubs feature — fully app-agnostic: depends only on
 * DISCORD_DATA_PORT + TRANSLATE_PORT + NOTIFICATION_PORT + inputs.
 */
declare class DiscordVoiceHubsComponent {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    canEdit: boolean;
    roles: DiscordRole[];
    set hubs(v: VoiceHub[] | null);
    private _hubs;
    private _busy;
    private _patternTimers;
    voiceHubs: _angular_core.Signal<VoiceHub[]>;
    busy: _angular_core.Signal<boolean>;
    roleOptions: _angular_core.Signal<SelectOption[]>;
    hubNameFromPattern(pattern: string): string;
    roleName(roleId: string): string;
    roleColor(roleId: string): string;
    addHub(): void;
    removeHub(channelId: string): void;
    onPatternInput(channelId: string, event: Event): void;
    addRole(channelId: string, roleId: string | null): void;
    removeRole(channelId: string, roleId: string): void;
    private patchHub;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordVoiceHubsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordVoiceHubsComponent, "svt-discord-voice-hubs", never, { "clientId": { "alias": "clientId"; "required": false; }; "canEdit": { "alias": "canEdit"; "required": false; }; "roles": { "alias": "roles"; "required": false; }; "hubs": { "alias": "hubs"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DiscordLevelingComponent implements OnChanges {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    roles: DiscordRole[];
    loading: _angular_core.WritableSignal<boolean>;
    saving: _angular_core.WritableSignal<boolean>;
    private _cfg;
    cfg: _angular_core.Signal<LevelingConfig | null>;
    newRewardLevel: _angular_core.WritableSignal<number>;
    newRewardRoleId: _angular_core.WritableSignal<string>;
    roleOptions: _angular_core.Signal<SelectOption[]>;
    newRewardOption: _angular_core.Signal<SelectOption | null>;
    ngOnChanges(): void;
    private load;
    roleName(roleId: string): string;
    toggleEnabled(val: boolean): void;
    onMinLengthChange(val: string): void;
    addReward(): void;
    removeReward(level: number): void;
    save(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordLevelingComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordLevelingComponent, "svt-discord-leveling", never, { "clientId": { "alias": "clientId"; "required": false; }; "roles": { "alias": "roles"; "required": false; }; }, {}, never, never, true, never>;
}

interface PendingMapping {
    roleId: string;
    label: string;
}
declare class DiscordReactionRolesComponent implements OnChanges {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    roles: DiscordRole[];
    channels: DiscordChannel[];
    loading: _angular_core.WritableSignal<boolean>;
    creating: _angular_core.WritableSignal<boolean>;
    deleting: _angular_core.WritableSignal<string | null>;
    private _enabled;
    enabled: _angular_core.Signal<boolean>;
    private _panels;
    panels: _angular_core.Signal<ReactionPanel[]>;
    newChannelId: _angular_core.WritableSignal<string>;
    newTitle: _angular_core.WritableSignal<string>;
    newDescription: _angular_core.WritableSignal<string>;
    pendingMappings: _angular_core.WritableSignal<PendingMapping[]>;
    addRoleId: _angular_core.WritableSignal<string>;
    addLabel: _angular_core.WritableSignal<string>;
    roleOptions: _angular_core.Signal<SelectOption[]>;
    channelOptions: _angular_core.Signal<SelectOption[]>;
    selectedChannelOption: _angular_core.Signal<SelectOption | null>;
    selectedAddRoleOption: _angular_core.Signal<SelectOption | null>;
    ngOnChanges(): void;
    private load;
    toggleEnabled(val: boolean): void;
    roleName(roleId: string): string;
    addMapping(): void;
    removeMapping(idx: number): void;
    createPanel(): void;
    deletePanel(panelId: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordReactionRolesComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordReactionRolesComponent, "svt-discord-reaction-roles", never, { "clientId": { "alias": "clientId"; "required": false; }; "roles": { "alias": "roles"; "required": false; }; "channels": { "alias": "channels"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DiscordStatsComponent implements OnChanges {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    channels: DiscordChannel[];
    loading: _angular_core.WritableSignal<boolean>;
    saving: _angular_core.WritableSignal<boolean>;
    private _cfg;
    cfg: _angular_core.Signal<StatsChannelsConfig | null>;
    voiceChannelOptions: _angular_core.Signal<SelectOption[]>;
    selectedMemberChannelOption: _angular_core.Signal<SelectOption | null>;
    selectedOnlineChannelOption: _angular_core.Signal<SelectOption | null>;
    ngOnChanges(): void;
    private load;
    toggleEnabled(val: boolean): void;
    onMemberChannelChange(opt: SelectOption | null): void;
    onOnlineChannelChange(opt: SelectOption | null): void;
    onTemplateChange(field: 'member' | 'online', val: string): void;
    save(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordStatsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordStatsComponent, "svt-discord-stats", never, { "clientId": { "alias": "clientId"; "required": false; }; "channels": { "alias": "channels"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DiscordAutomodComponent implements OnChanges {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    loading: _angular_core.WritableSignal<boolean>;
    private _cfg;
    cfg: _angular_core.Signal<AutomodConfig | null>;
    errorMsg: _angular_core.WritableSignal<string | null>;
    ngOnChanges(): void;
    private load;
    toggleMaster(enabled: boolean): void;
    toggle(rule: 'linkFilter' | 'spamFilter' | 'mentionSpam', enabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordAutomodComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordAutomodComponent, "svt-discord-automod", never, { "clientId": { "alias": "clientId"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DiscordGiveawaysComponent implements OnChanges {
    private port;
    private i18n;
    private toastr;
    private t;
    clientId: string;
    channels: DiscordChannel[];
    hostUserId: string;
    readonly durationOptions: SelectOption[];
    loading: _angular_core.WritableSignal<boolean>;
    creating: _angular_core.WritableSignal<boolean>;
    deleting: _angular_core.WritableSignal<string | null>;
    private _enabled;
    enabled: _angular_core.Signal<boolean>;
    private _giveaways;
    activeGiveaways: _angular_core.Signal<DiscordGiveaway[]>;
    newChannelId: _angular_core.WritableSignal<string>;
    newPrize: _angular_core.WritableSignal<string>;
    newDuration: _angular_core.WritableSignal<string>;
    newWinnerCount: _angular_core.WritableSignal<number>;
    textChannelOptions: _angular_core.Signal<SelectOption[]>;
    selectedChannelOption: _angular_core.Signal<SelectOption | null>;
    selectedDurationOption: _angular_core.Signal<SelectOption | null>;
    onWinnerCountChange(val: string): void;
    ngOnChanges(): void;
    private load;
    toggleEnabled(val: boolean): void;
    createGiveaway(): void;
    deleteGiveaway(giveawayId: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DiscordGiveawaysComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DiscordGiveawaysComponent, "svt-discord-giveaways", never, { "clientId": { "alias": "clientId"; "required": false; }; "channels": { "alias": "channels"; "required": false; }; "hostUserId": { "alias": "hostUserId"; "required": false; }; }, {}, never, never, true, never>;
}

export { DISCORD_DATA_PORT, DiscordAutomodComponent, DiscordGiveawaysComponent, DiscordGreetingComponent, DiscordLevelingComponent, DiscordReactionRolesComponent, DiscordStatsComponent, DiscordVoiceHubsComponent, DiscordWelcomeComponent, LocalizePipe, NOTIFICATION_PORT, TRANSLATE_PORT };
export type { AutomodConfig, BuildingAlertsOptions, BuildingLeaderboardOptions, ChannelCategory, ChannelOptions, ChannelTier, CreateGiveawayPayload, CreateReactionPanelPayload, DiscordChannel, DiscordChannelConfig, DiscordConfig, DiscordDataPort, DiscordGameAccessMode, DiscordGiveaway, DiscordGuildConfigAdvanced, DiscordGuildSpace, DiscordRole, GiveawaysFeature, GreetingMode, GreetingSeed, GreetingSettingsPayload, KillfeedOptions, LevelEntry, LevelReward, LevelingConfig, NotificationPort, PvpStatsOptions, RaidProtectionOptions, RateLimitInfo, ReactionPanel, ReactionRoleMapping, ReactionRolesFeature, ServerStatusOptions, ServitiumInfoOptions, StatsChannelsConfig, TranslatePort, VoiceHub, WelcomeSeed };
