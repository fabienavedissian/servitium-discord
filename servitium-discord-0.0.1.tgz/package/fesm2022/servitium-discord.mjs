import * as i0 from '@angular/core';
import { InjectionToken, inject, Pipe, signal, computed, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { SvtCardComponent, SvtCardHeaderDirective, SvtInputComponent, SvtIconComponent, SvtToggleComponent, SvtSelectComponent, SvtButtonComponent } from '@servitium/ui';

const DISCORD_DATA_PORT = new InjectionToken('DISCORD_DATA_PORT');

const TRANSLATE_PORT = new InjectionToken('TRANSLATE_PORT');
/** `| localize` resolved through TRANSLATE_PORT. Impure so it follows language changes. */
class LocalizePipe {
    constructor() {
        this.port = inject(TRANSLATE_PORT);
    }
    transform(key, params) {
        return this.port.translate(key, params);
    }
    static { this.ɵfac = function LocalizePipe_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || LocalizePipe)(); }; }
    static { this.ɵpipe = /*@__PURE__*/ i0.ɵɵdefinePipe({ name: "localize", type: LocalizePipe, pure: false }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LocalizePipe, [{
        type: Pipe,
        args: [{ name: 'localize', standalone: true, pure: false }]
    }], null, null); })();

const NOTIFICATION_PORT = new InjectionToken('NOTIFICATION_PORT');

// Data shapes shared by the Discord feature components and the DiscordDataPort.
// Kept here so the lib is self-contained; each app maps its API responses to
// these types.

const _c0$6 = () => ({ standalone: true });
function DiscordWelcomeComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8)(1, "h3", 9);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 10);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "discordPage.welcomeTitle"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "discordPage.welcomeDescription"));
} }
function DiscordWelcomeComponent_Conditional_12_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 12);
    i0.ɵɵelement(1, "svt-icon", 22);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 20);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discordPage.loadingChannels"));
} }
function DiscordWelcomeComponent_Conditional_12_Conditional_8_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 7);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "discordPage.channelSavedHint"));
} }
function DiscordWelcomeComponent_Conditional_12_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 23)(1, "svt-select", 24);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵlistener("onSelect", function DiscordWelcomeComponent_Conditional_12_Conditional_8_Template_svt_select_onSelect_1_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.onChannelSelect($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵconditionalCreate(3, DiscordWelcomeComponent_Conditional_12_Conditional_8_Conditional_3_Template, 3, 3, "p", 7);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(2, 8, "discordPage.selectChannel"))("options", ctx_r2.channelOptions())("ngModel", ctx_r2.selectedChannel())("ngModelOptions", i0.ɵɵpureFunction0(10, _c0$6))("disabled", ctx_r2.isLoadingChannels)("searchable", true)("clearable", true);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r2.selectedChannel() && ctx_r2.channelMissingFromList() ? 3 : -1);
} }
function DiscordWelcomeComponent_Conditional_12_Conditional_51_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 18);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", ctx_r2.thumbnailUrl().trim(), i0.ɵɵsanitizeUrl);
} }
function DiscordWelcomeComponent_Conditional_12_Conditional_56_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 21);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", ctx_r2.imageUrl().trim(), i0.ɵɵsanitizeUrl);
} }
function DiscordWelcomeComponent_Conditional_12_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 11)(1, "label", 6);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 7);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(7, DiscordWelcomeComponent_Conditional_12_Conditional_7_Template, 5, 4, "div", 12)(8, DiscordWelcomeComponent_Conditional_12_Conditional_8_Template, 4, 11);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "div", 13)(10, "div", 3)(11, "label", 6);
    i0.ɵɵtext(12);
    i0.ɵɵpipe(13, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "p", 7);
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(17, "svt-input", 14);
    i0.ɵɵpipe(18, "localize");
    i0.ɵɵlistener("input", function DiscordWelcomeComponent_Conditional_12_Template_svt_input_input_17_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onTitleInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(19, "div", 3)(20, "label", 6);
    i0.ɵɵtext(21);
    i0.ɵɵpipe(22, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(23, "p", 7);
    i0.ɵɵtext(24);
    i0.ɵɵpipe(25, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(26, "svt-input", 14);
    i0.ɵɵpipe(27, "localize");
    i0.ɵɵlistener("input", function DiscordWelcomeComponent_Conditional_12_Template_svt_input_input_26_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onDescriptionInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(28, "div", 3)(29, "label", 6);
    i0.ɵɵtext(30);
    i0.ɵɵpipe(31, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(32, "p", 7);
    i0.ɵɵtext(33);
    i0.ɵɵpipe(34, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(35, "svt-input", 14);
    i0.ɵɵpipe(36, "localize");
    i0.ɵɵlistener("input", function DiscordWelcomeComponent_Conditional_12_Template_svt_input_input_35_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onThumbnailInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(37, "div", 3)(38, "label", 6);
    i0.ɵɵtext(39);
    i0.ɵɵpipe(40, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(41, "p", 7);
    i0.ɵɵtext(42);
    i0.ɵɵpipe(43, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(44, "svt-input", 14);
    i0.ɵɵpipe(45, "localize");
    i0.ɵɵlistener("input", function DiscordWelcomeComponent_Conditional_12_Template_svt_input_input_44_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onImageInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(46, "div", 15)(47, "span", 16);
    i0.ɵɵtext(48);
    i0.ɵɵpipe(49, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(50, "div", 17);
    i0.ɵɵconditionalCreate(51, DiscordWelcomeComponent_Conditional_12_Conditional_51_Template, 1, 1, "img", 18);
    i0.ɵɵelementStart(52, "strong", 19);
    i0.ɵɵtext(53);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(54, "span", 20);
    i0.ɵɵtext(55);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(56, DiscordWelcomeComponent_Conditional_12_Conditional_56_Template, 1, 1, "img", 21);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 32, "discordPage.welcomeChannel"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 34, "discordPage.welcomeChannelHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r2.isLoadingChannels ? 7 : 8);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(13, 36, "discordPage.welcomeCustomTitle"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 38, "discordPage.welcomeCustomTitleHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r2.title())("ngModelOptions", i0.ɵɵpureFunction0(62, _c0$6))("placeholder", i0.ɵɵpipeBind1(18, 40, "discordPage.welcomeCustomTitlePlaceholder"))("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(22, 42, "discordPage.welcomeCustomMessage"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(25, 44, "discordPage.welcomeCustomMessageHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r2.description())("ngModelOptions", i0.ɵɵpureFunction0(63, _c0$6))("placeholder", i0.ɵɵpipeBind1(27, 46, "discordPage.welcomeCustomMessagePlaceholder"))("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(31, 48, "discordPage.welcomeCustomLogo"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(34, 50, "discordPage.welcomeCustomLogoHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r2.thumbnailUrl())("ngModelOptions", i0.ɵɵpureFunction0(64, _c0$6))("placeholder", i0.ɵɵpipeBind1(36, 52, "discordPage.welcomeCustomLogoPlaceholder"))("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(40, 54, "discordPage.welcomeCustomImage"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(43, 56, "discordPage.welcomeCustomImageHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r2.imageUrl())("ngModelOptions", i0.ɵɵpureFunction0(65, _c0$6))("placeholder", i0.ɵɵpipeBind1(45, 58, "discordPage.welcomeCustomImagePlaceholder"))("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(49, 60, "discordPage.welcomePreviewLabel"));
    i0.ɵɵadvance(3);
    i0.ɵɵconditional(ctx_r2.thumbnailUrl().trim() ? 51 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r2.previewTitle());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r2.previewDescription());
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.imageUrl().trim() ? 56 : -1);
} }
/**
 * "Welcome message" feature — fully app-agnostic: depends only on
 * DISCORD_DATA_PORT + TRANSLATE_PORT + NOTIFICATION_PORT + inputs.
 */
class DiscordWelcomeComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k, p) => this.i18n.translate(k, p);
        this.clientId = '';
        this.canEdit = false;
        this.availableChannels = [];
        this.isLoadingChannels = false;
        this.serverName = '';
        this.welcomeChannelName = null;
        this._channelId = signal(null, ...(ngDevMode ? [{ debugName: "_channelId" }] : []));
        this._enabled = signal(false, ...(ngDevMode ? [{ debugName: "_enabled" }] : []));
        this._selectedChannel = signal('', ...(ngDevMode ? [{ debugName: "_selectedChannel" }] : []));
        this._imageUrl = signal('', ...(ngDevMode ? [{ debugName: "_imageUrl" }] : []));
        this._thumbnailUrl = signal('', ...(ngDevMode ? [{ debugName: "_thumbnailUrl" }] : []));
        this._title = signal('', ...(ngDevMode ? [{ debugName: "_title" }] : []));
        this._description = signal('', ...(ngDevMode ? [{ debugName: "_description" }] : []));
        this._saveTimer = null;
        this.enabled = computed(() => this._enabled(), ...(ngDevMode ? [{ debugName: "enabled" }] : []));
        this.selectedChannel = computed(() => this._selectedChannel(), ...(ngDevMode ? [{ debugName: "selectedChannel" }] : []));
        this.imageUrl = computed(() => this._imageUrl(), ...(ngDevMode ? [{ debugName: "imageUrl" }] : []));
        this.thumbnailUrl = computed(() => this._thumbnailUrl(), ...(ngDevMode ? [{ debugName: "thumbnailUrl" }] : []));
        this.title = computed(() => this._title(), ...(ngDevMode ? [{ debugName: "title" }] : []));
        this.description = computed(() => this._description(), ...(ngDevMode ? [{ debugName: "description" }] : []));
        this.previewTitle = computed(() => this._title().trim() || 'Welcome', ...(ngDevMode ? [{ debugName: "previewTitle" }] : []));
        this.previewDescription = computed(() => {
            const raw = this._description().trim();
            const server = this.serverName || 'the server';
            const text = raw || `to **${server}**!`;
            return text.replace(/\{user\}/g, 'NewMember').replace(/\{server\}/g, server).replace(/\{mention\}/g, '@NewMember');
        }, ...(ngDevMode ? [{ debugName: "previewDescription" }] : []));
    }
    set welcome(v) {
        if (!v)
            return;
        this._channelId.set(v.channelId ?? null);
        this._enabled.set(!!v.channelId);
        this._selectedChannel.set(v.channelId ?? '');
        this._imageUrl.set(v.imageUrl || '');
        this._thumbnailUrl.set(v.thumbnailUrl || '');
        this._title.set(v.title || '');
        this._description.set(v.description || '');
    }
    // Method (not computed): availableChannels is a plain @Input, not a signal,
    // so a computed caches the initial empty list. A welcome message goes to a
    // text channel, so exclude voice/stage/category (text=0, announcement=5).
    channelOptions() {
        return this.availableChannels
            .filter(c => c.type === 0 || c.type === 5)
            .map(c => ({ value: c.id, label: `# ${c.name}` }));
    }
    onToggle(enabled) {
        this._enabled.set(enabled);
        if (!enabled)
            this.onChannelChange(null);
    }
    onChannelSelect(option) {
        this.onChannelChange(option?.value || null);
    }
    onChannelChange(channelId) {
        if (!this.clientId || !this.canEdit)
            return;
        this._channelId.set(channelId);
        this._selectedChannel.set(channelId || '');
        this._enabled.set(!!channelId);
        this.port.updateWelcomeChannel(this.clientId, channelId).subscribe({
            next: () => this.toastr.success(this.t('common.success'), this.t('discordPage.welcomeSettingsSaved')),
            error: () => this.toastr.error(this.t('common.error'), this.t('discordPage.welcomeSettingsFailed')),
        });
    }
    channelMissingFromList() {
        const id = this._channelId();
        if (!id)
            return false;
        return !this.availableChannels.some(c => c.id === id);
    }
    onTitleInput(e) { this._title.set(e.target?.value ?? ''); this.scheduleSave(); }
    onDescriptionInput(e) { this._description.set(e.target?.value ?? ''); this.scheduleSave(); }
    onThumbnailInput(e) { this._thumbnailUrl.set(e.target?.value ?? ''); this.scheduleSave(); }
    onImageInput(e) { this._imageUrl.set(e.target?.value ?? ''); this.scheduleSave(); }
    scheduleSave() {
        if (this._saveTimer)
            clearTimeout(this._saveTimer);
        this._saveTimer = setTimeout(() => this.saveSettings(), 900);
    }
    saveSettings() {
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateWelcomeSettings(this.clientId, {
            imageUrl: this._imageUrl().trim() || null,
            thumbnailUrl: this._thumbnailUrl().trim() || null,
            title: this._title().trim() || null,
            description: this._description().trim() || null,
        }).subscribe({
            next: () => this.toastr.success(this.t('common.success'), this.t('discordPage.welcomeSettingsSaved')),
            error: () => this.toastr.error(this.t('common.error'), this.t('discordPage.welcomeSettingsFailed')),
        });
    }
    static { this.ɵfac = function DiscordWelcomeComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordWelcomeComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordWelcomeComponent, selectors: [["svt-discord-welcome"]], inputs: { clientId: "clientId", canEdit: "canEdit", availableChannels: "availableChannels", isLoadingChannels: "isLoadingChannels", serverName: "serverName", welcomeChannelName: "welcomeChannelName", welcome: "welcome" }, decls: 13, vars: 9, consts: [["className", "discord-welcome__card svt-profile-card"], ["svtCardHeader", ""], [1, "discord-welcome__config"], [1, "discord-welcome__form-field"], [1, "discord-welcome__toggle-with-label"], ["variant", "survival", "size", "sm", 3, "toggleChange", "checked", "disabled"], [1, "discord-welcome__form-label"], [1, "discord-welcome__form-helper"], [1, "svt-dashboard__card-header"], [1, "svt-dashboard__card-title"], [1, "discord-welcome__subtitle"], [1, "discord-welcome__form-field", 2, "margin-top", "1rem"], [1, "discord-welcome__loading-channels"], [1, "discord-welcome__custom"], [3, "input", "ngModel", "ngModelOptions", "placeholder", "disabled"], [1, "discord-welcome__preview"], [1, "discord-welcome__preview-label"], [1, "discord-welcome__preview-embed"], ["alt", "", 1, "discord-welcome__preview-thumb", 3, "src"], [1, "discord-welcome__preview-title"], [1, "discord-welcome__preview-desc"], ["alt", "", 1, "discord-welcome__preview-image", 3, "src"], ["name", "loader-2", 3, "size"], [1, "discord-welcome__select-field"], ["size", "medium", 3, "onSelect", "placeholder", "options", "ngModel", "ngModelOptions", "disabled", "searchable", "clearable"]], template: function DiscordWelcomeComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card", 0);
            i0.ɵɵtemplate(1, DiscordWelcomeComponent_ng_template_1_Template, 7, 6, "ng-template", 1);
            i0.ɵɵelementStart(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "svt-toggle", 5);
            i0.ɵɵlistener("toggleChange", function DiscordWelcomeComponent_Template_svt_toggle_toggleChange_5_listener($event) { return ctx.onToggle($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "label", 6);
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "localize");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(9, "p", 7);
            i0.ɵɵtext(10);
            i0.ɵɵpipe(11, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(12, DiscordWelcomeComponent_Conditional_12_Template, 57, 66);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("checked", ctx.enabled())("disabled", !ctx.canEdit);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 5, "discordPage.enableWelcome"));
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(11, 7, "discordPage.welcomeHint"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.enabled() ? 12 : -1);
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtInputComponent,
            SvtIconComponent,
            SvtToggleComponent,
            SvtSelectComponent,
            LocalizePipe], styles: [".discord-welcome__subtitle[_ngcontent-%COMP%]{font-size:var(--svt-text-sm);color:var(--svt-text-secondary);margin:0;line-height:1.5}.discord-welcome__config[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--svt-gap-component)}.discord-welcome__form-field[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--svt-space-2)}.discord-welcome__form-label[_ngcontent-%COMP%]{font-size:var(--svt-text-sm);font-weight:var(--svt-font-weight-medium);color:var(--svt-text-primary)}.discord-welcome__form-helper[_ngcontent-%COMP%]{font-size:var(--svt-text-xs);color:var(--svt-text-tertiary);margin:0;line-height:1.5}.discord-welcome__select-field[_ngcontent-%COMP%]{width:100%}.discord-welcome__select-field[_ngcontent-%COMP%]   svt-select[_ngcontent-%COMP%]{width:100%}.discord-welcome__loading-channels[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--svt-gap-inner);padding:var(--svt-gap-component);color:var(--svt-text-tertiary);font-size:var(--svt-text-sm)}.discord-welcome__toggle-with-label[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--svt-space-3);padding:var(--svt-space-2-5) var(--svt-space-3);border:1px solid var(--svt-border-primary);border-radius:var(--svt-radius-md);background:transparent;transition:border-color var(--svt-duration-fast) var(--svt-ease-out)}.discord-welcome__toggle-with-label[_ngcontent-%COMP%]:hover{border-color:var(--svt-border-strong)}.discord-welcome__custom[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:1rem;margin-top:1.25rem;padding-top:1.25rem;border-top:1px solid var(--svt-border, rgba(255, 255, 255, .08))}.discord-welcome__preview[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.5rem}.discord-welcome__preview-label[_ngcontent-%COMP%]{font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;color:var(--svt-text-muted, rgba(255, 255, 255, .5))}.discord-welcome__preview-embed[_ngcontent-%COMP%]{position:relative;display:flex;flex-direction:column;gap:.35rem;padding:.85rem 1rem;border-radius:8px;background:var(--svt-surface-2, rgba(0, 0, 0, .25));border-left:4px solid #00d4ff;max-width:480px;width:100%;box-sizing:border-box}.discord-welcome__preview-thumb[_ngcontent-%COMP%]{position:absolute;top:.85rem;right:1rem;width:48px;height:48px;border-radius:6px;object-fit:cover}.discord-welcome__preview-title[_ngcontent-%COMP%]{font-size:1rem;color:var(--svt-text, #fff)}.discord-welcome__preview-desc[_ngcontent-%COMP%]{font-size:.9rem;color:var(--svt-text-secondary, rgba(255, 255, 255, .75))}.discord-welcome__preview-image[_ngcontent-%COMP%]{margin-top:.5rem;max-width:400px;max-height:300px;width:auto;height:auto;border-radius:6px}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordWelcomeComponent, [{
        type: Component,
        args: [{ selector: 'svt-discord-welcome', standalone: true, imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtToggleComponent,
                    SvtSelectComponent,
                    LocalizePipe,
                ], template: "<svt-card className=\"discord-welcome__card svt-profile-card\">\n  <ng-template svtCardHeader>\n    <div class=\"svt-dashboard__card-header\">\n      <h3 class=\"svt-dashboard__card-title\">{{ 'discordPage.welcomeTitle' | localize }}</h3>\n      <p class=\"discord-welcome__subtitle\">{{ 'discordPage.welcomeDescription' | localize }}</p>\n    </div>\n  </ng-template>\n\n  <div class=\"discord-welcome__config\">\n    <div class=\"discord-welcome__form-field\">\n      <div class=\"discord-welcome__toggle-with-label\">\n        <svt-toggle\n          variant=\"survival\"\n          size=\"sm\"\n          [checked]=\"enabled()\"\n          [disabled]=\"!canEdit\"\n          (toggleChange)=\"onToggle($event)\"\n        />\n        <label class=\"discord-welcome__form-label\">{{ 'discordPage.enableWelcome' | localize }}</label>\n      </div>\n      <p class=\"discord-welcome__form-helper\">{{ 'discordPage.welcomeHint' | localize }}</p>\n\n      @if (enabled()) {\n        <div class=\"discord-welcome__form-field\" style=\"margin-top: 1rem;\">\n          <label class=\"discord-welcome__form-label\">{{ 'discordPage.welcomeChannel' | localize }}</label>\n          <p class=\"discord-welcome__form-helper\">{{ 'discordPage.welcomeChannelHint' | localize }}</p>\n          @if (isLoadingChannels) {\n            <div class=\"discord-welcome__loading-channels\">\n              <svt-icon name=\"loader-2\" [size]=\"20\" />\n              <span>{{ 'discordPage.loadingChannels' | localize }}</span>\n            </div>\n          } @else {\n            <div class=\"discord-welcome__select-field\">\n              <svt-select\n                size=\"medium\"\n                [placeholder]=\"'discordPage.selectChannel' | localize\"\n                [options]=\"channelOptions()\"\n                [ngModel]=\"selectedChannel()\"\n                [ngModelOptions]=\"{ standalone: true }\"\n                [disabled]=\"isLoadingChannels\"\n                [searchable]=\"true\"\n                [clearable]=\"true\"\n                (onSelect)=\"onChannelSelect($event)\"\n              />\n            </div>\n            @if (selectedChannel() && channelMissingFromList()) {\n              <p class=\"discord-welcome__form-helper\">{{ 'discordPage.channelSavedHint' | localize }}</p>\n            }\n          }\n        </div>\n\n        <div class=\"discord-welcome__custom\">\n          <div class=\"discord-welcome__form-field\">\n            <label class=\"discord-welcome__form-label\">{{ 'discordPage.welcomeCustomTitle' | localize }}</label>\n            <p class=\"discord-welcome__form-helper\">{{ 'discordPage.welcomeCustomTitleHint' | localize }}</p>\n            <svt-input\n              [ngModel]=\"title()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [placeholder]=\"'discordPage.welcomeCustomTitlePlaceholder' | localize\"\n              [disabled]=\"!canEdit\"\n              (input)=\"onTitleInput($event)\"\n            />\n          </div>\n\n          <div class=\"discord-welcome__form-field\">\n            <label class=\"discord-welcome__form-label\">{{ 'discordPage.welcomeCustomMessage' | localize }}</label>\n            <p class=\"discord-welcome__form-helper\">{{ 'discordPage.welcomeCustomMessageHint' | localize }}</p>\n            <svt-input\n              [ngModel]=\"description()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [placeholder]=\"'discordPage.welcomeCustomMessagePlaceholder' | localize\"\n              [disabled]=\"!canEdit\"\n              (input)=\"onDescriptionInput($event)\"\n            />\n          </div>\n\n          <div class=\"discord-welcome__form-field\">\n            <label class=\"discord-welcome__form-label\">{{ 'discordPage.welcomeCustomLogo' | localize }}</label>\n            <p class=\"discord-welcome__form-helper\">{{ 'discordPage.welcomeCustomLogoHint' | localize }}</p>\n            <svt-input\n              [ngModel]=\"thumbnailUrl()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [placeholder]=\"'discordPage.welcomeCustomLogoPlaceholder' | localize\"\n              [disabled]=\"!canEdit\"\n              (input)=\"onThumbnailInput($event)\"\n            />\n          </div>\n\n          <div class=\"discord-welcome__form-field\">\n            <label class=\"discord-welcome__form-label\">{{ 'discordPage.welcomeCustomImage' | localize }}</label>\n            <p class=\"discord-welcome__form-helper\">{{ 'discordPage.welcomeCustomImageHint' | localize }}</p>\n            <svt-input\n              [ngModel]=\"imageUrl()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [placeholder]=\"'discordPage.welcomeCustomImagePlaceholder' | localize\"\n              [disabled]=\"!canEdit\"\n              (input)=\"onImageInput($event)\"\n            />\n          </div>\n\n          <div class=\"discord-welcome__preview\">\n            <span class=\"discord-welcome__preview-label\">{{ 'discordPage.welcomePreviewLabel' | localize }}</span>\n            <div class=\"discord-welcome__preview-embed\">\n              @if (thumbnailUrl().trim()) {\n                <img class=\"discord-welcome__preview-thumb\" [src]=\"thumbnailUrl().trim()\" alt=\"\" />\n              }\n              <strong class=\"discord-welcome__preview-title\">{{ previewTitle() }}</strong>\n              <span class=\"discord-welcome__preview-desc\">{{ previewDescription() }}</span>\n              @if (imageUrl().trim()) {\n                <img class=\"discord-welcome__preview-image\" [src]=\"imageUrl().trim()\" alt=\"\" />\n              }\n            </div>\n          </div>\n        </div>\n      }\n    </div>\n  </div>\n</svt-card>\n", styles: [".discord-welcome__subtitle{font-size:var(--svt-text-sm);color:var(--svt-text-secondary);margin:0;line-height:1.5}.discord-welcome__config{display:flex;flex-direction:column;gap:var(--svt-gap-component)}.discord-welcome__form-field{display:flex;flex-direction:column;gap:var(--svt-space-2)}.discord-welcome__form-label{font-size:var(--svt-text-sm);font-weight:var(--svt-font-weight-medium);color:var(--svt-text-primary)}.discord-welcome__form-helper{font-size:var(--svt-text-xs);color:var(--svt-text-tertiary);margin:0;line-height:1.5}.discord-welcome__select-field{width:100%}.discord-welcome__select-field svt-select{width:100%}.discord-welcome__loading-channels{display:flex;align-items:center;gap:var(--svt-gap-inner);padding:var(--svt-gap-component);color:var(--svt-text-tertiary);font-size:var(--svt-text-sm)}.discord-welcome__toggle-with-label{display:flex;align-items:center;gap:var(--svt-space-3);padding:var(--svt-space-2-5) var(--svt-space-3);border:1px solid var(--svt-border-primary);border-radius:var(--svt-radius-md);background:transparent;transition:border-color var(--svt-duration-fast) var(--svt-ease-out)}.discord-welcome__toggle-with-label:hover{border-color:var(--svt-border-strong)}.discord-welcome__custom{display:flex;flex-direction:column;gap:1rem;margin-top:1.25rem;padding-top:1.25rem;border-top:1px solid var(--svt-border, rgba(255, 255, 255, .08))}.discord-welcome__preview{display:flex;flex-direction:column;gap:.5rem}.discord-welcome__preview-label{font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;color:var(--svt-text-muted, rgba(255, 255, 255, .5))}.discord-welcome__preview-embed{position:relative;display:flex;flex-direction:column;gap:.35rem;padding:.85rem 1rem;border-radius:8px;background:var(--svt-surface-2, rgba(0, 0, 0, .25));border-left:4px solid #00d4ff;max-width:480px;width:100%;box-sizing:border-box}.discord-welcome__preview-thumb{position:absolute;top:.85rem;right:1rem;width:48px;height:48px;border-radius:6px;object-fit:cover}.discord-welcome__preview-title{font-size:1rem;color:var(--svt-text, #fff)}.discord-welcome__preview-desc{font-size:.9rem;color:var(--svt-text-secondary, rgba(255, 255, 255, .75))}.discord-welcome__preview-image{margin-top:.5rem;max-width:400px;max-height:300px;width:auto;height:auto;border-radius:6px}\n"] }]
    }], null, { clientId: [{
            type: Input
        }], canEdit: [{
            type: Input
        }], availableChannels: [{
            type: Input
        }], isLoadingChannels: [{
            type: Input
        }], serverName: [{
            type: Input
        }], welcomeChannelName: [{
            type: Input
        }], welcome: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordWelcomeComponent, { className: "DiscordWelcomeComponent", filePath: "lib/components/discord-welcome.component.ts", lineNumber: 47 }); })();

const _c0$5 = () => ({ standalone: true });
function DiscordGreetingComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 7)(1, "h3", 8);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 9);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, ctx_r0.cardTitleKey()));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, ctx_r0.cardDescKey()));
} }
function DiscordGreetingComponent_Conditional_11_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵelement(1, "svt-icon", 32);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 20);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discordPage.loadingChannels"));
} }
function DiscordGreetingComponent_Conditional_11_Conditional_8_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 6);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "discordPage.channelSavedHint"));
} }
function DiscordGreetingComponent_Conditional_11_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "svt-select", 33);
    i0.ɵɵpipe(1, "localize");
    i0.ɵɵlistener("onSelect", function DiscordGreetingComponent_Conditional_11_Conditional_8_Template_svt_select_onSelect_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.onChannelSelect($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(2, DiscordGreetingComponent_Conditional_11_Conditional_8_Conditional_2_Template, 3, 3, "p", 6);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(1, 7, "discordPage.selectChannel"))("options", ctx_r0.channelOptions())("ngModel", ctx_r0.selectedChannel())("ngModelOptions", i0.ɵɵpureFunction0(9, _c0$5))("searchable", true)("clearable", true);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r0.selectedChannel() && ctx_r0.channelMissingFromList() ? 2 : -1);
} }
function DiscordGreetingComponent_Conditional_11_For_29_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 34);
    i0.ɵɵlistener("click", function DiscordGreetingComponent_Conditional_11_For_29_Template_button_click_0_listener() { const v_r5 = i0.ɵɵrestoreView(_r4).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.insertVariable(v_r5)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const v_r5 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(v_r5);
} }
function DiscordGreetingComponent_Conditional_11_Conditional_36_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 10)(1, "div", 3)(2, "svt-toggle", 4);
    i0.ɵɵlistener("toggleChange", function DiscordGreetingComponent_Conditional_11_Conditional_36_Template_svt_toggle_toggleChange_2_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.onPingToggle($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "label", 5);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "localize");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "p", 6);
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("checked", ctx_r0.ping())("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 4, "discordApp.greetingPing"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 6, "discordApp.greetingPingHint"));
} }
function DiscordGreetingComponent_Conditional_11_Conditional_46_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 20)(1, "label", 5);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "input", 19);
    i0.ɵɵlistener("input", function DiscordGreetingComponent_Conditional_11_Conditional_46_Template_input_input_4_listener($event) { i0.ɵɵrestoreView(_r7); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.onBannerColorInput($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "discordApp.greetingBannerColor"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("value", ctx_r0.bannerColor())("disabled", !ctx_r0.canEdit);
} }
function DiscordGreetingComponent_Conditional_11_Conditional_67_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 35);
    i0.ɵɵelement(1, "div", 36);
    i0.ɵɵelementStart(2, "div", 37)(3, "strong");
    i0.ɵɵtext(4, "NewMember");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "span");
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("background", "linear-gradient(135deg, " + ctx_r0.bannerColor() + "55, #05060b)");
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(ctx_r0.previewSubtitle());
} }
function DiscordGreetingComponent_Conditional_11_Conditional_69_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 25);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", ctx_r0.thumbnailUrl().trim(), i0.ɵɵsanitizeUrl);
} }
function DiscordGreetingComponent_Conditional_11_Conditional_74_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 28);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", ctx_r0.imageUrl().trim(), i0.ɵɵsanitizeUrl);
} }
function DiscordGreetingComponent_Conditional_11_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 10)(1, "label", 5);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 6);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(7, DiscordGreetingComponent_Conditional_11_Conditional_7_Template, 5, 4, "div", 11)(8, DiscordGreetingComponent_Conditional_11_Conditional_8_Template, 3, 10);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "div", 12)(10, "div", 13)(11, "div", 10)(12, "label", 5);
    i0.ɵɵtext(13);
    i0.ɵɵpipe(14, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(15, "svt-input", 14);
    i0.ɵɵlistener("input", function DiscordGreetingComponent_Conditional_11_Template_svt_input_input_15_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onTitleInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(16, "div", 10)(17, "label", 5);
    i0.ɵɵtext(18);
    i0.ɵɵpipe(19, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(20, "p", 6);
    i0.ɵɵtext(21);
    i0.ɵɵpipe(22, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(23, "svt-input", 14);
    i0.ɵɵlistener("input", function DiscordGreetingComponent_Conditional_11_Template_svt_input_input_23_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onDescriptionInput($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(24, "div", 15)(25, "span", 16);
    i0.ɵɵtext(26);
    i0.ɵɵpipe(27, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵrepeaterCreate(28, DiscordGreetingComponent_Conditional_11_For_29_Template, 2, 2, "button", 17, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(30, "div", 18)(31, "div", 10)(32, "label", 5);
    i0.ɵɵtext(33);
    i0.ɵɵpipe(34, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(35, "input", 19);
    i0.ɵɵlistener("input", function DiscordGreetingComponent_Conditional_11_Template_input_input_35_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onColorInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵconditionalCreate(36, DiscordGreetingComponent_Conditional_11_Conditional_36_Template, 9, 8, "div", 10);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(37, "div", 10)(38, "div", 3)(39, "svt-toggle", 4);
    i0.ɵɵlistener("toggleChange", function DiscordGreetingComponent_Conditional_11_Template_svt_toggle_toggleChange_39_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onBannerToggle($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(40, "label", 5);
    i0.ɵɵtext(41);
    i0.ɵɵpipe(42, "localize");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(43, "p", 6);
    i0.ɵɵtext(44);
    i0.ɵɵpipe(45, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(46, DiscordGreetingComponent_Conditional_11_Conditional_46_Template, 5, 5, "div", 20);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(47, "div", 10)(48, "label", 5);
    i0.ɵɵtext(49);
    i0.ɵɵpipe(50, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(51, "p", 6);
    i0.ɵɵtext(52);
    i0.ɵɵpipe(53, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(54, "svt-input", 14);
    i0.ɵɵlistener("input", function DiscordGreetingComponent_Conditional_11_Template_svt_input_input_54_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onThumbnailInput($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(55, "div", 10)(56, "label", 5);
    i0.ɵɵtext(57);
    i0.ɵɵpipe(58, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(59, "p", 6);
    i0.ɵɵtext(60);
    i0.ɵɵpipe(61, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(62, "svt-input", 14);
    i0.ɵɵlistener("input", function DiscordGreetingComponent_Conditional_11_Template_svt_input_input_62_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onImageInput($event)); });
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(63, "div", 21)(64, "span", 22);
    i0.ɵɵtext(65);
    i0.ɵɵpipe(66, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(67, DiscordGreetingComponent_Conditional_11_Conditional_67_Template, 7, 3, "div", 23);
    i0.ɵɵelementStart(68, "div", 24);
    i0.ɵɵconditionalCreate(69, DiscordGreetingComponent_Conditional_11_Conditional_69_Template, 1, 1, "img", 25);
    i0.ɵɵelementStart(70, "strong", 26);
    i0.ɵɵtext(71);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(72, "span", 27);
    i0.ɵɵtext(73);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(74, DiscordGreetingComponent_Conditional_11_Conditional_74_Template, 1, 1, "img", 28);
    i0.ɵɵelementStart(75, "span", 29);
    i0.ɵɵtext(76, "Servitium");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(77, "svt-button", 30);
    i0.ɵɵlistener("onClick", function DiscordGreetingComponent_Conditional_11_Template_svt_button_onClick_77_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.sendTest()); });
    i0.ɵɵelement(78, "svt-icon", 31);
    i0.ɵɵtext(79);
    i0.ɵɵpipe(80, "localize");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 43, "discordApp.greetingChannel"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 45, "discordApp.greetingChannelHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r0.isLoadingChannels ? 7 : 8);
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(14, 47, "discordApp.greetingMessageTitle"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r0.title())("ngModelOptions", i0.ɵɵpureFunction0(73, _c0$5))("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(19, 49, "discordApp.greetingMessageText"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(22, 51, "discordApp.greetingMessageTextHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r0.description())("ngModelOptions", i0.ɵɵpureFunction0(74, _c0$5))("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(27, 53, "discordApp.greetingVariablesLabel"));
    i0.ɵɵadvance(2);
    i0.ɵɵrepeater(ctx_r0.variables);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(34, 55, "discordApp.greetingColor"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("value", ctx_r0.color())("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.isWelcome() ? 36 : -1);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("checked", ctx_r0.bannerEnabled())("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(42, 57, "discordApp.greetingBanner"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(45, 59, "discordApp.greetingBannerHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r0.bannerEnabled() ? 46 : -1);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(50, 61, "discordApp.greetingLogo"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(53, 63, "discordApp.greetingLogoHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r0.thumbnailUrl())("ngModelOptions", i0.ɵɵpureFunction0(75, _c0$5))("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(58, 65, "discordApp.greetingImage"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(61, 67, "discordApp.greetingImageHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", ctx_r0.imageUrl())("ngModelOptions", i0.ɵɵpureFunction0(76, _c0$5))("disabled", !ctx_r0.canEdit);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(66, 69, "discordApp.greetingPreview"));
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r0.bannerEnabled() ? 67 : -1);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("border-color", ctx_r0.color());
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.thumbnailUrl().trim() ? 69 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.previewTitle());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.previewDescription());
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.imageUrl().trim() ? 74 : -1);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("disabled", !ctx_r0.enabled());
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 15);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(80, 71, "discordApp.greetingTest"), " ");
} }
const VARIABLES = ['{user}', '{user.mention}', '{server}', '{memberCount}'];
/**
 * Greeting editor for BOTH the welcome (join) and goodbye (leave) messages —
 * driven by the `mode` input. App-agnostic: depends only on the three ports +
 * inputs. Variables, accent color, ping (welcome only), auto banner, live
 * preview and a "send test" action.
 */
class DiscordGreetingComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k, p) => this.i18n.translate(k, p);
        this.clientId = '';
        this.canEdit = false;
        this.mode = 'welcome';
        this.availableChannels = [];
        this.isLoadingChannels = false;
        this.serverName = '';
        this.variables = VARIABLES;
        this._enabled = signal(false, ...(ngDevMode ? [{ debugName: "_enabled" }] : []));
        this._channelId = signal(null, ...(ngDevMode ? [{ debugName: "_channelId" }] : []));
        this._selectedChannel = signal('', ...(ngDevMode ? [{ debugName: "_selectedChannel" }] : []));
        this._title = signal('', ...(ngDevMode ? [{ debugName: "_title" }] : []));
        this._description = signal('', ...(ngDevMode ? [{ debugName: "_description" }] : []));
        this._imageUrl = signal('', ...(ngDevMode ? [{ debugName: "_imageUrl" }] : []));
        this._thumbnailUrl = signal('', ...(ngDevMode ? [{ debugName: "_thumbnailUrl" }] : []));
        this._color = signal('', ...(ngDevMode ? [{ debugName: "_color" }] : []));
        this._ping = signal(true, ...(ngDevMode ? [{ debugName: "_ping" }] : []));
        this._bannerEnabled = signal(false, ...(ngDevMode ? [{ debugName: "_bannerEnabled" }] : []));
        this._bannerColor = signal('', ...(ngDevMode ? [{ debugName: "_bannerColor" }] : []));
        this._saveTimer = null;
        this.isWelcome = computed(() => this.mode === 'welcome', ...(ngDevMode ? [{ debugName: "isWelcome" }] : []));
        this.enabled = computed(() => this._enabled(), ...(ngDevMode ? [{ debugName: "enabled" }] : []));
        this.selectedChannel = computed(() => this._selectedChannel(), ...(ngDevMode ? [{ debugName: "selectedChannel" }] : []));
        this.title = computed(() => this._title(), ...(ngDevMode ? [{ debugName: "title" }] : []));
        this.description = computed(() => this._description(), ...(ngDevMode ? [{ debugName: "description" }] : []));
        this.imageUrl = computed(() => this._imageUrl(), ...(ngDevMode ? [{ debugName: "imageUrl" }] : []));
        this.thumbnailUrl = computed(() => this._thumbnailUrl(), ...(ngDevMode ? [{ debugName: "thumbnailUrl" }] : []));
        this.color = computed(() => this._color() || (this.mode === 'welcome' ? '#5865f2' : '#ed4245'), ...(ngDevMode ? [{ debugName: "color" }] : []));
        this.ping = computed(() => this._ping(), ...(ngDevMode ? [{ debugName: "ping" }] : []));
        this.bannerEnabled = computed(() => this._bannerEnabled(), ...(ngDevMode ? [{ debugName: "bannerEnabled" }] : []));
        this.bannerColor = computed(() => this._bannerColor() || this.color(), ...(ngDevMode ? [{ debugName: "bannerColor" }] : []));
        // Mode-specific i18n keys (mode never changes after init).
        this.modeCap = computed(() => (this.mode === 'welcome' ? 'Welcome' : 'Goodbye'), ...(ngDevMode ? [{ debugName: "modeCap" }] : []));
        this.cardTitleKey = computed(() => `discordApp.greeting${this.modeCap()}Title`, ...(ngDevMode ? [{ debugName: "cardTitleKey" }] : []));
        this.cardDescKey = computed(() => `discordApp.greeting${this.modeCap()}Desc`, ...(ngDevMode ? [{ debugName: "cardDescKey" }] : []));
        this.enableLabelKey = computed(() => `discordApp.greeting${this.modeCap()}Enable`, ...(ngDevMode ? [{ debugName: "enableLabelKey" }] : []));
        this.previewTitle = computed(() => this.substitute(this._title().trim()) || (this.mode === 'welcome' ? 'Welcome' : 'Goodbye'), ...(ngDevMode ? [{ debugName: "previewTitle" }] : []));
        this.previewDescription = computed(() => {
            const server = this.serverName || 'the server';
            const fallback = this.mode === 'welcome' ? `Welcome to **${server}**!` : `**NewMember** left the server.`;
            return this.substitute(this._description().trim() || fallback);
        }, ...(ngDevMode ? [{ debugName: "previewDescription" }] : []));
        this.previewSubtitle = computed(() => (this.mode === 'welcome' ? 'Member #1,234' : "We'll miss you"), ...(ngDevMode ? [{ debugName: "previewSubtitle" }] : []));
    }
    set greeting(v) {
        if (!v)
            return;
        this._enabled.set(!!v.enabled);
        this._channelId.set(v.channelId ?? null);
        this._selectedChannel.set(v.channelId ?? '');
        this._title.set(v.title || '');
        this._description.set(v.description || '');
        this._imageUrl.set(v.imageUrl || '');
        this._thumbnailUrl.set(v.thumbnailUrl || '');
        this._color.set(v.color || '');
        this._ping.set(v.ping !== false);
        this._bannerEnabled.set(!!v.bannerEnabled);
        this._bannerColor.set(v.bannerColor || '');
    }
    // Method (not computed): availableChannels is a plain @Input, not a signal,
    // so a computed would cache the initial empty list and never update when the
    // channels load async. Only text/announcement channels can receive a message.
    channelOptions() {
        return this.availableChannels
            .filter(c => c.type === 0 || c.type === 5)
            .map(c => ({ value: c.id, label: `# ${c.name}` }));
    }
    substitute(text) {
        const server = this.serverName || 'the server';
        return text
            .replace(/\{user\.mention\}/gi, '@NewMember')
            .replace(/\{mention\}/gi, '@NewMember')
            .replace(/\{user\.name\}/gi, 'NewMember')
            .replace(/\{user\}/gi, 'NewMember')
            .replace(/\{server\}/gi, server)
            .replace(/\{membercount\}/gi, '1,234');
    }
    channelMissingFromList() {
        const id = this._channelId();
        if (!id)
            return false;
        return !this.availableChannels.some(c => c.id === id);
    }
    onToggle(enabled) {
        this._enabled.set(enabled);
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateGreetingSettings(this.clientId, this.mode, { enabled }).subscribe({
            next: () => this.saved(),
            error: () => this.failed(),
        });
    }
    onChannelSelect(option) {
        const channelId = option?.value || null;
        this._channelId.set(channelId);
        this._selectedChannel.set(channelId || '');
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateGreetingChannel(this.clientId, this.mode, channelId).subscribe({
            next: () => this.saved(),
            error: () => this.failed(),
        });
    }
    insertVariable(v) {
        if (!this.canEdit)
            return;
        this._description.update(d => (d ? `${d} ${v}` : v));
        this.scheduleSave();
    }
    onTitleInput(e) { this._title.set(e.target?.value ?? ''); this.scheduleSave(); }
    onDescriptionInput(e) { this._description.set(e.target?.value ?? ''); this.scheduleSave(); }
    onThumbnailInput(e) { this._thumbnailUrl.set(e.target?.value ?? ''); this.scheduleSave(); }
    onImageInput(e) { this._imageUrl.set(e.target?.value ?? ''); this.scheduleSave(); }
    onColorInput(e) { this._color.set(e.target?.value ?? ''); this.scheduleSave(); }
    onBannerColorInput(e) { this._bannerColor.set(e.target?.value ?? ''); this.scheduleSave(); }
    onPingToggle(ping) {
        this._ping.set(ping);
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateGreetingSettings(this.clientId, this.mode, { ping }).subscribe({ next: () => this.saved(), error: () => this.failed() });
    }
    onBannerToggle(bannerEnabled) {
        this._bannerEnabled.set(bannerEnabled);
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateGreetingSettings(this.clientId, this.mode, { bannerEnabled }).subscribe({ next: () => this.saved(), error: () => this.failed() });
    }
    sendTest() {
        if (!this.clientId)
            return;
        this.port.sendGreetingTest(this.clientId, this.mode).subscribe({
            next: () => this.toastr.success(this.t('common.success'), this.t('discordApp.greetingTestSent')),
            error: () => this.toastr.error(this.t('common.error'), this.t('discordApp.greetingTestFailed')),
        });
    }
    scheduleSave() {
        if (this._saveTimer)
            clearTimeout(this._saveTimer);
        this._saveTimer = setTimeout(() => this.saveSettings(), 900);
    }
    saveSettings() {
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateGreetingSettings(this.clientId, this.mode, {
            title: this._title().trim() || null,
            description: this._description().trim() || null,
            imageUrl: this._imageUrl().trim() || null,
            thumbnailUrl: this._thumbnailUrl().trim() || null,
            color: this._color().trim() || null,
            bannerColor: this._bannerColor().trim() || null,
        }).subscribe({ next: () => this.saved(), error: () => this.failed() });
    }
    saved() { this.toastr.success(this.t('common.success'), this.t('discordApp.greetingSaved')); }
    failed() { this.toastr.error(this.t('common.error'), this.t('discordApp.greetingSaveFailed')); }
    static { this.ɵfac = function DiscordGreetingComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordGreetingComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordGreetingComponent, selectors: [["svt-discord-greeting"]], inputs: { clientId: "clientId", canEdit: "canEdit", mode: "mode", availableChannels: "availableChannels", isLoadingChannels: "isLoadingChannels", serverName: "serverName", greeting: "greeting" }, decls: 12, vars: 9, consts: [["className", "discord-greeting__card svt-profile-card"], ["svtCardHeader", ""], [1, "discord-greeting__config"], [1, "discord-greeting__toggle-with-label"], ["variant", "survival", "size", "sm", 3, "toggleChange", "checked", "disabled"], [1, "discord-greeting__form-label"], [1, "discord-greeting__form-helper"], [1, "svt-dashboard__card-header"], [1, "svt-dashboard__card-title"], [1, "discord-greeting__subtitle"], [1, "discord-greeting__form-field"], [1, "discord-greeting__loading-channels"], [1, "discord-greeting__grid"], [1, "discord-greeting__editor"], [3, "input", "ngModel", "ngModelOptions", "disabled"], [1, "discord-greeting__vars"], [1, "discord-greeting__vars-label"], ["type", "button", 1, "discord-greeting__var", 3, "disabled"], [1, "discord-greeting__row"], ["type", "color", 1, "discord-greeting__color", 3, "input", "value", "disabled"], [1, "discord-greeting__form-field", 2, "margin-top", "0.6rem"], [1, "discord-greeting__preview-pane"], [1, "discord-greeting__preview-label"], [1, "discord-greeting__banner", 3, "background"], [1, "discord-greeting__embed"], ["alt", "", 1, "discord-greeting__embed-thumb", 3, "src"], [1, "discord-greeting__embed-title"], [1, "discord-greeting__embed-desc"], ["alt", "", 1, "discord-greeting__embed-image", 3, "src"], [1, "discord-greeting__embed-footer"], ["variant", "secondary", "size", "small", 3, "onClick", "disabled"], ["name", "send", 3, "size"], ["name", "loader-2", 3, "size"], ["size", "medium", 3, "onSelect", "placeholder", "options", "ngModel", "ngModelOptions", "searchable", "clearable"], ["type", "button", 1, "discord-greeting__var", 3, "click", "disabled"], [1, "discord-greeting__banner"], [1, "discord-greeting__banner-avatar"], [1, "discord-greeting__banner-text"]], template: function DiscordGreetingComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card", 0);
            i0.ɵɵtemplate(1, DiscordGreetingComponent_ng_template_1_Template, 7, 6, "ng-template", 1);
            i0.ɵɵelementStart(2, "div", 2)(3, "div", 3)(4, "svt-toggle", 4);
            i0.ɵɵlistener("toggleChange", function DiscordGreetingComponent_Template_svt_toggle_toggleChange_4_listener($event) { return ctx.onToggle($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "label", 5);
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "localize");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(8, "p", 6);
            i0.ɵɵtext(9);
            i0.ɵɵpipe(10, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(11, DiscordGreetingComponent_Conditional_11_Template, 81, 77);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("checked", ctx.enabled())("disabled", !ctx.canEdit);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 5, ctx.enableLabelKey()));
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 7, "discordApp.greetingEnableHint"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.enabled() ? 11 : -1);
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtInputComponent,
            SvtIconComponent,
            SvtToggleComponent,
            SvtSelectComponent,
            SvtButtonComponent,
            LocalizePipe], styles: [".discord-greeting__subtitle[_ngcontent-%COMP%]{margin:.25rem 0 0;color:var(--svt-text-secondary);font-size:var(--svt-text-sm)}.discord-greeting__config[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.75rem}.discord-greeting__toggle-with-label[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.6rem}.discord-greeting__form-field[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.35rem}.discord-greeting__form-label[_ngcontent-%COMP%]{font-size:var(--svt-text-sm);font-weight:600;color:var(--svt-text-primary)}.discord-greeting__form-helper[_ngcontent-%COMP%]{margin:0;font-size:var(--svt-text-xs);color:var(--svt-text-secondary)}.discord-greeting__loading-channels[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.5rem;color:var(--svt-text-secondary)}.discord-greeting__grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr;gap:1.25rem;margin-top:.5rem}@media (min-width: 920px){.discord-greeting__grid[_ngcontent-%COMP%]{grid-template-columns:1.2fr 1fr}}.discord-greeting__editor[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:1rem}.discord-greeting__row[_ngcontent-%COMP%]{display:flex;gap:1.25rem;flex-wrap:wrap;align-items:flex-start}.discord-greeting__vars[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem;margin-top:.35rem}.discord-greeting__vars-label[_ngcontent-%COMP%]{font-size:var(--svt-text-xs);color:var(--svt-text-secondary);margin-right:.2rem}.discord-greeting__var[_ngcontent-%COMP%]{font-family:var(--svt-font-mono, monospace);font-size:.75rem;padding:.15rem .45rem;border-radius:6px;border:1px solid var(--svt-border-color, rgba(255, 255, 255, .12));background:var(--svt-bg-tertiary, rgba(255, 255, 255, .04));color:var(--svt-text-secondary);cursor:pointer}.discord-greeting__var[_ngcontent-%COMP%]:hover:not(:disabled){color:var(--svt-text-primary);border-color:#5865f2}.discord-greeting__var[_ngcontent-%COMP%]:disabled{opacity:.5;cursor:default}.discord-greeting__color[_ngcontent-%COMP%]{width:56px;height:34px;padding:0;border:1px solid var(--svt-border-color, rgba(255, 255, 255, .12));border-radius:8px;background:transparent;cursor:pointer}.discord-greeting__preview-pane[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.6rem;padding:1rem;border-radius:12px;background:var(--svt-bg-secondary, rgba(255, 255, 255, .02));border:1px solid var(--svt-border-color, rgba(255, 255, 255, .08));align-self:start}.discord-greeting__preview-label[_ngcontent-%COMP%]{font-size:var(--svt-text-xs);text-transform:uppercase;letter-spacing:.04em;color:var(--svt-text-secondary)}.discord-greeting__banner[_ngcontent-%COMP%]{position:relative;height:120px;border-radius:10px;display:flex;align-items:center;gap:.85rem;padding:0 1rem;overflow:hidden}.discord-greeting__banner-avatar[_ngcontent-%COMP%]{width:72px;height:72px;border-radius:50%;background:#ffffff2e;border:3px solid rgba(255,255,255,.55);flex-shrink:0}.discord-greeting__banner-text[_ngcontent-%COMP%]{display:flex;flex-direction:column;color:#fff}.discord-greeting__banner-text[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:1.15rem}.discord-greeting__banner-text[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.8rem;opacity:.85}.discord-greeting__embed[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.3rem;padding:.75rem .9rem;border-radius:4px;border-left:4px solid #5865f2;background:var(--svt-bg-tertiary, #2b2d31)}.discord-greeting__embed-thumb[_ngcontent-%COMP%]{width:48px;height:48px;border-radius:8px;object-fit:cover;align-self:flex-start}.discord-greeting__embed-title[_ngcontent-%COMP%]{color:var(--svt-text-primary);font-size:1rem}.discord-greeting__embed-desc[_ngcontent-%COMP%]{color:var(--svt-text-secondary);font-size:.9rem;white-space:pre-wrap}.discord-greeting__embed-image[_ngcontent-%COMP%]{margin-top:.4rem;max-width:100%;border-radius:8px}.discord-greeting__embed-footer[_ngcontent-%COMP%]{margin-top:.3rem;font-size:.7rem;color:var(--svt-text-tertiary, rgba(255, 255, 255, .4))}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordGreetingComponent, [{
        type: Component,
        args: [{ selector: 'svt-discord-greeting', standalone: true, imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtToggleComponent,
                    SvtSelectComponent,
                    SvtButtonComponent,
                    LocalizePipe,
                ], template: "<svt-card className=\"discord-greeting__card svt-profile-card\">\n  <ng-template svtCardHeader>\n    <div class=\"svt-dashboard__card-header\">\n      <h3 class=\"svt-dashboard__card-title\">{{ cardTitleKey() | localize }}</h3>\n      <p class=\"discord-greeting__subtitle\">{{ cardDescKey() | localize }}</p>\n    </div>\n  </ng-template>\n\n  <div class=\"discord-greeting__config\">\n    <div class=\"discord-greeting__toggle-with-label\">\n      <svt-toggle\n        variant=\"survival\"\n        size=\"sm\"\n        [checked]=\"enabled()\"\n        [disabled]=\"!canEdit\"\n        (toggleChange)=\"onToggle($event)\"\n      />\n      <label class=\"discord-greeting__form-label\">{{ enableLabelKey() | localize }}</label>\n    </div>\n    <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingEnableHint' | localize }}</p>\n\n    @if (enabled()) {\n      <!-- Channel -->\n      <div class=\"discord-greeting__form-field\">\n        <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingChannel' | localize }}</label>\n        <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingChannelHint' | localize }}</p>\n        @if (isLoadingChannels) {\n          <div class=\"discord-greeting__loading-channels\">\n            <svt-icon name=\"loader-2\" [size]=\"20\" />\n            <span>{{ 'discordPage.loadingChannels' | localize }}</span>\n          </div>\n        } @else {\n          <svt-select\n            size=\"medium\"\n            [placeholder]=\"'discordPage.selectChannel' | localize\"\n            [options]=\"channelOptions()\"\n            [ngModel]=\"selectedChannel()\"\n            [ngModelOptions]=\"{ standalone: true }\"\n            [searchable]=\"true\"\n            [clearable]=\"true\"\n            (onSelect)=\"onChannelSelect($event)\"\n          />\n          @if (selectedChannel() && channelMissingFromList()) {\n            <p class=\"discord-greeting__form-helper\">{{ 'discordPage.channelSavedHint' | localize }}</p>\n          }\n        }\n      </div>\n\n      <div class=\"discord-greeting__grid\">\n        <div class=\"discord-greeting__editor\">\n          <!-- Title -->\n          <div class=\"discord-greeting__form-field\">\n            <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingMessageTitle' | localize }}</label>\n            <svt-input\n              [ngModel]=\"title()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [disabled]=\"!canEdit\"\n              (input)=\"onTitleInput($event)\"\n            />\n          </div>\n\n          <!-- Message + variables -->\n          <div class=\"discord-greeting__form-field\">\n            <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingMessageText' | localize }}</label>\n            <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingMessageTextHint' | localize }}</p>\n            <svt-input\n              [ngModel]=\"description()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [disabled]=\"!canEdit\"\n              (input)=\"onDescriptionInput($event)\"\n            />\n            <div class=\"discord-greeting__vars\">\n              <span class=\"discord-greeting__vars-label\">{{ 'discordApp.greetingVariablesLabel' | localize }}</span>\n              @for (v of variables; track v) {\n                <button type=\"button\" class=\"discord-greeting__var\" [disabled]=\"!canEdit\" (click)=\"insertVariable(v)\">{{ v }}</button>\n              }\n            </div>\n          </div>\n\n          <!-- Accent color + ping -->\n          <div class=\"discord-greeting__row\">\n            <div class=\"discord-greeting__form-field\">\n              <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingColor' | localize }}</label>\n              <input type=\"color\" class=\"discord-greeting__color\" [value]=\"color()\" [disabled]=\"!canEdit\" (input)=\"onColorInput($event)\" />\n            </div>\n            @if (isWelcome()) {\n              <div class=\"discord-greeting__form-field\">\n                <div class=\"discord-greeting__toggle-with-label\">\n                  <svt-toggle variant=\"survival\" size=\"sm\" [checked]=\"ping()\" [disabled]=\"!canEdit\" (toggleChange)=\"onPingToggle($event)\" />\n                  <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingPing' | localize }}</label>\n                </div>\n                <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingPingHint' | localize }}</p>\n              </div>\n            }\n          </div>\n\n          <!-- Banner -->\n          <div class=\"discord-greeting__form-field\">\n            <div class=\"discord-greeting__toggle-with-label\">\n              <svt-toggle variant=\"survival\" size=\"sm\" [checked]=\"bannerEnabled()\" [disabled]=\"!canEdit\" (toggleChange)=\"onBannerToggle($event)\" />\n              <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingBanner' | localize }}</label>\n            </div>\n            <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingBannerHint' | localize }}</p>\n            @if (bannerEnabled()) {\n              <div class=\"discord-greeting__form-field\" style=\"margin-top: 0.6rem;\">\n                <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingBannerColor' | localize }}</label>\n                <input type=\"color\" class=\"discord-greeting__color\" [value]=\"bannerColor()\" [disabled]=\"!canEdit\" (input)=\"onBannerColorInput($event)\" />\n              </div>\n            }\n          </div>\n\n          <!-- Logo + image -->\n          <div class=\"discord-greeting__form-field\">\n            <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingLogo' | localize }}</label>\n            <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingLogoHint' | localize }}</p>\n            <svt-input [ngModel]=\"thumbnailUrl()\" [ngModelOptions]=\"{ standalone: true }\" [disabled]=\"!canEdit\" (input)=\"onThumbnailInput($event)\" />\n          </div>\n          <div class=\"discord-greeting__form-field\">\n            <label class=\"discord-greeting__form-label\">{{ 'discordApp.greetingImage' | localize }}</label>\n            <p class=\"discord-greeting__form-helper\">{{ 'discordApp.greetingImageHint' | localize }}</p>\n            <svt-input [ngModel]=\"imageUrl()\" [ngModelOptions]=\"{ standalone: true }\" [disabled]=\"!canEdit\" (input)=\"onImageInput($event)\" />\n          </div>\n        </div>\n\n        <!-- Preview -->\n        <div class=\"discord-greeting__preview-pane\">\n          <span class=\"discord-greeting__preview-label\">{{ 'discordApp.greetingPreview' | localize }}</span>\n          @if (bannerEnabled()) {\n            <div class=\"discord-greeting__banner\" [style.background]=\"'linear-gradient(135deg, ' + bannerColor() + '55, #05060b)'\">\n              <div class=\"discord-greeting__banner-avatar\"></div>\n              <div class=\"discord-greeting__banner-text\">\n                <strong>NewMember</strong>\n                <span>{{ previewSubtitle() }}</span>\n              </div>\n            </div>\n          }\n          <div class=\"discord-greeting__embed\" [style.borderColor]=\"color()\">\n            @if (thumbnailUrl().trim()) {\n              <img class=\"discord-greeting__embed-thumb\" [src]=\"thumbnailUrl().trim()\" alt=\"\" />\n            }\n            <strong class=\"discord-greeting__embed-title\">{{ previewTitle() }}</strong>\n            <span class=\"discord-greeting__embed-desc\">{{ previewDescription() }}</span>\n            @if (imageUrl().trim()) {\n              <img class=\"discord-greeting__embed-image\" [src]=\"imageUrl().trim()\" alt=\"\" />\n            }\n            <span class=\"discord-greeting__embed-footer\">Servitium</span>\n          </div>\n          <svt-button variant=\"secondary\" size=\"small\" [disabled]=\"!enabled()\" (onClick)=\"sendTest()\">\n            <svt-icon name=\"send\" [size]=\"15\" />\n            {{ 'discordApp.greetingTest' | localize }}\n          </svt-button>\n        </div>\n      </div>\n    }\n  </div>\n</svt-card>\n", styles: [".discord-greeting__subtitle{margin:.25rem 0 0;color:var(--svt-text-secondary);font-size:var(--svt-text-sm)}.discord-greeting__config{display:flex;flex-direction:column;gap:.75rem}.discord-greeting__toggle-with-label{display:flex;align-items:center;gap:.6rem}.discord-greeting__form-field{display:flex;flex-direction:column;gap:.35rem}.discord-greeting__form-label{font-size:var(--svt-text-sm);font-weight:600;color:var(--svt-text-primary)}.discord-greeting__form-helper{margin:0;font-size:var(--svt-text-xs);color:var(--svt-text-secondary)}.discord-greeting__loading-channels{display:flex;align-items:center;gap:.5rem;color:var(--svt-text-secondary)}.discord-greeting__grid{display:grid;grid-template-columns:1fr;gap:1.25rem;margin-top:.5rem}@media (min-width: 920px){.discord-greeting__grid{grid-template-columns:1.2fr 1fr}}.discord-greeting__editor{display:flex;flex-direction:column;gap:1rem}.discord-greeting__row{display:flex;gap:1.25rem;flex-wrap:wrap;align-items:flex-start}.discord-greeting__vars{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem;margin-top:.35rem}.discord-greeting__vars-label{font-size:var(--svt-text-xs);color:var(--svt-text-secondary);margin-right:.2rem}.discord-greeting__var{font-family:var(--svt-font-mono, monospace);font-size:.75rem;padding:.15rem .45rem;border-radius:6px;border:1px solid var(--svt-border-color, rgba(255, 255, 255, .12));background:var(--svt-bg-tertiary, rgba(255, 255, 255, .04));color:var(--svt-text-secondary);cursor:pointer}.discord-greeting__var:hover:not(:disabled){color:var(--svt-text-primary);border-color:#5865f2}.discord-greeting__var:disabled{opacity:.5;cursor:default}.discord-greeting__color{width:56px;height:34px;padding:0;border:1px solid var(--svt-border-color, rgba(255, 255, 255, .12));border-radius:8px;background:transparent;cursor:pointer}.discord-greeting__preview-pane{display:flex;flex-direction:column;gap:.6rem;padding:1rem;border-radius:12px;background:var(--svt-bg-secondary, rgba(255, 255, 255, .02));border:1px solid var(--svt-border-color, rgba(255, 255, 255, .08));align-self:start}.discord-greeting__preview-label{font-size:var(--svt-text-xs);text-transform:uppercase;letter-spacing:.04em;color:var(--svt-text-secondary)}.discord-greeting__banner{position:relative;height:120px;border-radius:10px;display:flex;align-items:center;gap:.85rem;padding:0 1rem;overflow:hidden}.discord-greeting__banner-avatar{width:72px;height:72px;border-radius:50%;background:#ffffff2e;border:3px solid rgba(255,255,255,.55);flex-shrink:0}.discord-greeting__banner-text{display:flex;flex-direction:column;color:#fff}.discord-greeting__banner-text strong{font-size:1.15rem}.discord-greeting__banner-text span{font-size:.8rem;opacity:.85}.discord-greeting__embed{display:flex;flex-direction:column;gap:.3rem;padding:.75rem .9rem;border-radius:4px;border-left:4px solid #5865f2;background:var(--svt-bg-tertiary, #2b2d31)}.discord-greeting__embed-thumb{width:48px;height:48px;border-radius:8px;object-fit:cover;align-self:flex-start}.discord-greeting__embed-title{color:var(--svt-text-primary);font-size:1rem}.discord-greeting__embed-desc{color:var(--svt-text-secondary);font-size:.9rem;white-space:pre-wrap}.discord-greeting__embed-image{margin-top:.4rem;max-width:100%;border-radius:8px}.discord-greeting__embed-footer{margin-top:.3rem;font-size:.7rem;color:var(--svt-text-tertiary, rgba(255, 255, 255, .4))}\n"] }]
    }], null, { clientId: [{
            type: Input
        }], canEdit: [{
            type: Input
        }], mode: [{
            type: Input
        }], availableChannels: [{
            type: Input
        }], isLoadingChannels: [{
            type: Input
        }], serverName: [{
            type: Input
        }], greeting: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordGreetingComponent, { className: "DiscordGreetingComponent", filePath: "lib/components/discord-greeting.component.ts", lineNumber: 45 }); })();

const _c0$4 = () => ({ standalone: true });
const _forTrack0$3 = ($index, $item) => $item.channelId;
function DiscordVoiceHubsComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 7)(1, "h3", 8);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 9);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "discordPage.voiceHubTitle"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "discordPage.voiceHubDescription"));
} }
function DiscordVoiceHubsComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 3);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "discordPage.voiceHubEmpty"));
} }
function DiscordVoiceHubsComponent_For_5_Conditional_26_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 22);
    i0.ɵɵelement(1, "span", 23);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 24);
    i0.ɵɵlistener("click", function DiscordVoiceHubsComponent_For_5_Conditional_26_For_2_Template_button_click_4_listener() { const roleId_r5 = i0.ɵɵrestoreView(_r4).$implicit; const hub_r2 = i0.ɵɵnextContext(2).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.removeRole(hub_r2.channelId, roleId_r5)); });
    i0.ɵɵelement(5, "svt-icon", 25);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const roleId_r5 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("background-color", ctx_r2.roleColor(roleId_r5));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r2.roleName(roleId_r5));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("size", 14);
} }
function DiscordVoiceHubsComponent_For_5_Conditional_26_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 21);
    i0.ɵɵrepeaterCreate(1, DiscordVoiceHubsComponent_For_5_Conditional_26_For_2_Template, 6, 4, "div", 22, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const hub_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵrepeater(hub_r2.allowedRoleIds);
} }
function DiscordVoiceHubsComponent_For_5_Conditional_27_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 3);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "discordPage.voiceHubRolesOpen"));
} }
function DiscordVoiceHubsComponent_For_5_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "div", 10)(2, "h4", 11);
    i0.ɵɵelement(3, "svt-icon", 12);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "svt-button", 13);
    i0.ɵɵlistener("click", function DiscordVoiceHubsComponent_For_5_Template_svt_button_click_5_listener() { const hub_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.removeHub(hub_r2.channelId)); });
    i0.ɵɵelement(6, "svt-icon", 14);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(7, "div", 15)(8, "label", 16);
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "p", 17);
    i0.ɵɵtext(12);
    i0.ɵɵpipe(13, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "svt-input", 18);
    i0.ɵɵpipe(15, "localize");
    i0.ɵɵlistener("input", function DiscordVoiceHubsComponent_For_5_Template_svt_input_input_14_listener($event) { const hub_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onPatternInput(hub_r2.channelId, $event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(16, "div", 15)(17, "label", 16);
    i0.ɵɵtext(18);
    i0.ɵɵpipe(19, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(20, "p", 17);
    i0.ɵɵtext(21);
    i0.ɵɵpipe(22, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(23, "div", 19)(24, "svt-select", 20);
    i0.ɵɵpipe(25, "localize");
    i0.ɵɵlistener("onSelect", function DiscordVoiceHubsComponent_For_5_Template_svt_select_onSelect_24_listener($event) { const hub_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.addRole(hub_r2.channelId, ($event == null ? null : $event.value) || null)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵconditionalCreate(26, DiscordVoiceHubsComponent_For_5_Conditional_26_Template, 3, 0, "div", 21)(27, DiscordVoiceHubsComponent_For_5_Conditional_27_Template, 3, 3, "p", 3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const hub_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("size", 16);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r2.hubNameFromPattern(hub_r2.namePattern));
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 14);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 20, "discordPage.voiceHubPattern"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(13, 22, "discordPage.voiceHubPatternHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngModel", hub_r2.namePattern)("ngModelOptions", i0.ɵɵpureFunction0(32, _c0$4))("placeholder", i0.ɵɵpipeBind1(15, 24, "discordPage.voiceHubPatternPlaceholder"))("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(19, 26, "discordPage.voiceHubRoles"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(22, 28, "discordPage.voiceHubRolesHint"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("options", ctx_r2.roleOptions())("clearable", false)("searchable", true)("placeholder", i0.ɵɵpipeBind1(25, 30, "discordPage.voiceHubAddRole"))("ngModel", "")("ngModelOptions", i0.ɵɵpureFunction0(33, _c0$4))("disabled", !ctx_r2.canEdit);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(hub_r2.allowedRoleIds.length > 0 ? 26 : 27);
} }
const DEFAULT_PATTERN = 'Voice {n}';
/**
 * "Join to Create" voice hubs feature — fully app-agnostic: depends only on
 * DISCORD_DATA_PORT + TRANSLATE_PORT + NOTIFICATION_PORT + inputs.
 */
class DiscordVoiceHubsComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k, p) => this.i18n.translate(k, p);
        this.clientId = '';
        this.canEdit = false;
        this.roles = [];
        this._hubs = signal([], ...(ngDevMode ? [{ debugName: "_hubs" }] : []));
        this._busy = signal(false, ...(ngDevMode ? [{ debugName: "_busy" }] : []));
        this._patternTimers = new Map();
        this.voiceHubs = computed(() => this._hubs(), ...(ngDevMode ? [{ debugName: "voiceHubs" }] : []));
        this.busy = computed(() => this._busy(), ...(ngDevMode ? [{ debugName: "busy" }] : []));
        this.roleOptions = computed(() => this.roles.map(r => ({ value: r.id, label: r.name })), ...(ngDevMode ? [{ debugName: "roleOptions" }] : []));
    }
    set hubs(v) {
        this._hubs.set((v || []).map(h => ({ ...h, allowedRoleIds: [...(h.allowedRoleIds || [])] })));
    }
    hubNameFromPattern(pattern) {
        const base = (pattern || DEFAULT_PATTERN).replace(/\{n\}/g, '').replace(/\s+/g, ' ').trim();
        return base || 'Voice';
    }
    roleName(roleId) {
        return this.roles.find(r => r.id === roleId)?.name || roleId;
    }
    roleColor(roleId) {
        const role = this.roles.find(r => r.id === roleId);
        return role ? '#' + role.color.toString(16).padStart(6, '0') : 'var(--svt-text-muted, #888)';
    }
    addHub() {
        if (!this.clientId || !this.canEdit)
            return;
        this._busy.set(true);
        this.port.createVoiceHub(this.clientId, { namePattern: DEFAULT_PATTERN, allowedRoleIds: [] }).subscribe({
            next: res => {
                this._busy.set(false);
                if (res.hub)
                    this._hubs.update(h => [...h, res.hub]);
                this.toastr.success(this.t('common.success'), this.t('discordPage.voiceHubCreated'));
            },
            error: () => {
                this._busy.set(false);
                this.toastr.error(this.t('common.error'), this.t('discordPage.voiceHubFailed'));
            },
        });
    }
    removeHub(channelId) {
        if (!this.clientId || !this.canEdit)
            return;
        const prev = this._hubs();
        this._hubs.update(h => h.filter(x => x.channelId !== channelId));
        this.port.deleteVoiceHub(this.clientId, channelId).subscribe({
            next: () => this.toastr.success(this.t('common.success'), this.t('discordPage.voiceHubRemoved')),
            error: () => {
                this._hubs.set(prev);
                this.toastr.error(this.t('common.error'), this.t('discordPage.voiceHubFailed'));
            },
        });
    }
    onPatternInput(channelId, event) {
        const value = event.target?.value ?? '';
        this._hubs.update(h => h.map(x => x.channelId === channelId ? { ...x, namePattern: value } : x));
        const existing = this._patternTimers.get(channelId);
        if (existing)
            clearTimeout(existing);
        this._patternTimers.set(channelId, setTimeout(() => {
            this.patchHub(channelId, { namePattern: value.trim() || DEFAULT_PATTERN });
        }, 900));
    }
    addRole(channelId, roleId) {
        if (!roleId)
            return;
        const hub = this._hubs().find(h => h.channelId === channelId);
        if (!hub || hub.allowedRoleIds.includes(roleId))
            return;
        const roles = [...hub.allowedRoleIds, roleId];
        this._hubs.update(h => h.map(x => x.channelId === channelId ? { ...x, allowedRoleIds: roles } : x));
        this.patchHub(channelId, { allowedRoleIds: roles });
    }
    removeRole(channelId, roleId) {
        const hub = this._hubs().find(h => h.channelId === channelId);
        if (!hub)
            return;
        const roles = hub.allowedRoleIds.filter(r => r !== roleId);
        this._hubs.update(h => h.map(x => x.channelId === channelId ? { ...x, allowedRoleIds: roles } : x));
        this.patchHub(channelId, { allowedRoleIds: roles });
    }
    patchHub(channelId, settings) {
        if (!this.clientId || !this.canEdit)
            return;
        this.port.updateVoiceHub(this.clientId, channelId, settings).subscribe({
            next: () => this.toastr.success(this.t('common.success'), this.t('discordPage.voiceHubSaved')),
            error: () => this.toastr.error(this.t('common.error'), this.t('discordPage.voiceHubFailed')),
        });
    }
    static { this.ɵfac = function DiscordVoiceHubsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordVoiceHubsComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordVoiceHubsComponent, selectors: [["svt-discord-voice-hubs"]], inputs: { clientId: "clientId", canEdit: "canEdit", roles: "roles", hubs: "hubs" }, decls: 10, vars: 6, consts: [["className", "discord-voice-hubs__card svt-profile-card"], ["svtCardHeader", ""], [1, "discord-voice-hubs__config"], [1, "discord-voice-hubs__empty"], [1, "discord-voice-hubs__hub"], ["variant", "secondary", "size", "small", 3, "click", "disabled"], ["name", "plus", 3, "size"], [1, "svt-dashboard__card-header"], [1, "svt-dashboard__card-title"], [1, "discord-voice-hubs__subtitle"], [1, "discord-voice-hubs__hub-head"], [1, "discord-voice-hubs__hub-title"], ["name", "volume-2", 3, "size"], ["variant", "danger", "size", "small", 3, "click", "disabled"], ["name", "trash-2", 3, "size"], [1, "discord-voice-hubs__form-field"], [1, "discord-voice-hubs__form-label"], [1, "discord-voice-hubs__form-helper"], [3, "input", "ngModel", "ngModelOptions", "placeholder", "disabled"], [1, "discord-voice-hubs__controls"], ["size", "small", 3, "onSelect", "options", "clearable", "searchable", "placeholder", "ngModel", "ngModelOptions", "disabled"], [1, "discord-voice-hubs__role-list"], [1, "discord-voice-hubs__role-chip"], [1, "discord-voice-hubs__chip-dot"], [1, "discord-voice-hubs__chip-remove", 3, "click"], ["name", "x", 3, "size"]], template: function DiscordVoiceHubsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card", 0);
            i0.ɵɵtemplate(1, DiscordVoiceHubsComponent_ng_template_1_Template, 7, 6, "ng-template", 1);
            i0.ɵɵelementStart(2, "div", 2);
            i0.ɵɵconditionalCreate(3, DiscordVoiceHubsComponent_Conditional_3_Template, 3, 3, "p", 3);
            i0.ɵɵrepeaterCreate(4, DiscordVoiceHubsComponent_For_5_Template, 28, 34, "div", 4, _forTrack0$3);
            i0.ɵɵelementStart(6, "svt-button", 5);
            i0.ɵɵlistener("click", function DiscordVoiceHubsComponent_Template_svt_button_click_6_listener() { return ctx.addHub(); });
            i0.ɵɵelement(7, "svt-icon", 6);
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "localize");
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.voiceHubs().length === 0 ? 3 : -1);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.voiceHubs());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canEdit || ctx.busy());
            i0.ɵɵadvance();
            i0.ɵɵproperty("size", 14);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 4, "discordPage.voiceHubAdd"), " ");
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtButtonComponent,
            SvtInputComponent,
            SvtIconComponent,
            SvtSelectComponent,
            LocalizePipe], styles: [".discord-voice-hubs__subtitle[_ngcontent-%COMP%]{font-size:var(--svt-text-sm);color:var(--svt-text-secondary);margin:0;line-height:1.5}.discord-voice-hubs__config[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--svt-gap-component)}.discord-voice-hubs__hub[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.85rem;padding:1rem;border-radius:8px;background:var(--svt-surface-2, rgba(0, 0, 0, .18));border:1px solid var(--svt-border, rgba(255, 255, 255, .08));margin-bottom:1rem}.discord-voice-hubs__hub-head[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:1rem}.discord-voice-hubs__hub-title[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--svt-space-2);margin:0;font-size:var(--svt-text-sm);font-weight:var(--svt-font-weight-semibold);color:var(--svt-text-primary)}.discord-voice-hubs__form-field[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--svt-space-2)}.discord-voice-hubs__form-label[_ngcontent-%COMP%]{font-size:var(--svt-text-sm);font-weight:var(--svt-font-weight-medium);color:var(--svt-text-primary)}.discord-voice-hubs__form-helper[_ngcontent-%COMP%]{font-size:var(--svt-text-xs);color:var(--svt-text-tertiary);margin:0;line-height:1.5}.discord-voice-hubs__controls[_ngcontent-%COMP%]{display:flex;gap:var(--svt-gap-inner);align-items:center;flex-wrap:wrap}.discord-voice-hubs__controls[_ngcontent-%COMP%]   svt-select[_ngcontent-%COMP%]{flex:1;min-width:220px}.discord-voice-hubs__empty[_ngcontent-%COMP%]{margin:0;padding:var(--svt-space-4);text-align:center;color:var(--svt-text-secondary);font-size:var(--svt-text-sm);font-style:italic;background:var(--svt-bg-tertiary);border:2px dashed var(--svt-border-primary);border-radius:var(--svt-radius-sm)}.discord-voice-hubs__role-list[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:var(--svt-gap-inner)}.discord-voice-hubs__role-chip[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:var(--svt-space-2);padding:var(--svt-space-1) var(--svt-space-3);background:var(--svt-bg-primary);border:1px solid var(--svt-border-primary);border-radius:var(--svt-radius-full);font-size:var(--svt-text-sm);color:var(--svt-text-primary)}.discord-voice-hubs__chip-dot[_ngcontent-%COMP%]{width:10px;height:10px;border-radius:50%;flex-shrink:0}.discord-voice-hubs__chip-remove[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;padding:0;background:transparent;border:none;cursor:pointer;color:var(--svt-text-secondary);border-radius:50%}.discord-voice-hubs__chip-remove[_ngcontent-%COMP%]:hover{color:var(--svt-error-500)}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordVoiceHubsComponent, [{
        type: Component,
        args: [{ selector: 'svt-discord-voice-hubs', standalone: true, imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtButtonComponent,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtSelectComponent,
                    LocalizePipe,
                ], template: "<svt-card className=\"discord-voice-hubs__card svt-profile-card\">\n  <ng-template svtCardHeader>\n    <div class=\"svt-dashboard__card-header\">\n      <h3 class=\"svt-dashboard__card-title\">{{ 'discordPage.voiceHubTitle' | localize }}</h3>\n      <p class=\"discord-voice-hubs__subtitle\">{{ 'discordPage.voiceHubDescription' | localize }}</p>\n    </div>\n  </ng-template>\n\n  <div class=\"discord-voice-hubs__config\">\n    @if (voiceHubs().length === 0) {\n      <p class=\"discord-voice-hubs__empty\">{{ 'discordPage.voiceHubEmpty' | localize }}</p>\n    }\n\n    @for (hub of voiceHubs(); track hub.channelId) {\n      <div class=\"discord-voice-hubs__hub\">\n        <div class=\"discord-voice-hubs__hub-head\">\n          <h4 class=\"discord-voice-hubs__hub-title\"><svt-icon name=\"volume-2\" [size]=\"16\" /> {{ hubNameFromPattern(hub.namePattern) }}</h4>\n          <svt-button variant=\"danger\" size=\"small\" [disabled]=\"!canEdit\" (click)=\"removeHub(hub.channelId)\">\n            <svt-icon name=\"trash-2\" [size]=\"14\" />\n          </svt-button>\n        </div>\n\n        <div class=\"discord-voice-hubs__form-field\">\n          <label class=\"discord-voice-hubs__form-label\">{{ 'discordPage.voiceHubPattern' | localize }}</label>\n          <p class=\"discord-voice-hubs__form-helper\">{{ 'discordPage.voiceHubPatternHint' | localize }}</p>\n          <svt-input\n            [ngModel]=\"hub.namePattern\"\n            [ngModelOptions]=\"{ standalone: true }\"\n            [placeholder]=\"'discordPage.voiceHubPatternPlaceholder' | localize\"\n            [disabled]=\"!canEdit\"\n            (input)=\"onPatternInput(hub.channelId, $event)\"\n          />\n        </div>\n\n        <div class=\"discord-voice-hubs__form-field\">\n          <label class=\"discord-voice-hubs__form-label\">{{ 'discordPage.voiceHubRoles' | localize }}</label>\n          <p class=\"discord-voice-hubs__form-helper\">{{ 'discordPage.voiceHubRolesHint' | localize }}</p>\n          <div class=\"discord-voice-hubs__controls\">\n            <svt-select\n              size=\"small\"\n              [options]=\"roleOptions()\"\n              [clearable]=\"false\"\n              [searchable]=\"true\"\n              [placeholder]=\"'discordPage.voiceHubAddRole' | localize\"\n              [ngModel]=\"''\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [disabled]=\"!canEdit\"\n              (onSelect)=\"addRole(hub.channelId, $event?.value || null)\"\n            />\n          </div>\n          @if (hub.allowedRoleIds.length > 0) {\n            <div class=\"discord-voice-hubs__role-list\">\n              @for (roleId of hub.allowedRoleIds; track roleId) {\n                <div class=\"discord-voice-hubs__role-chip\">\n                  <span class=\"discord-voice-hubs__chip-dot\" [style.background-color]=\"roleColor(roleId)\"></span>\n                  <span>{{ roleName(roleId) }}</span>\n                  <button class=\"discord-voice-hubs__chip-remove\" (click)=\"removeRole(hub.channelId, roleId)\"><svt-icon name=\"x\" [size]=\"14\" /></button>\n                </div>\n              }\n            </div>\n          } @else {\n            <p class=\"discord-voice-hubs__empty\">{{ 'discordPage.voiceHubRolesOpen' | localize }}</p>\n          }\n        </div>\n      </div>\n    }\n\n    <svt-button variant=\"secondary\" size=\"small\" [disabled]=\"!canEdit || busy()\" (click)=\"addHub()\">\n      <svt-icon name=\"plus\" [size]=\"14\" /> {{ 'discordPage.voiceHubAdd' | localize }}\n    </svt-button>\n  </div>\n</svt-card>\n", styles: [".discord-voice-hubs__subtitle{font-size:var(--svt-text-sm);color:var(--svt-text-secondary);margin:0;line-height:1.5}.discord-voice-hubs__config{display:flex;flex-direction:column;gap:var(--svt-gap-component)}.discord-voice-hubs__hub{display:flex;flex-direction:column;gap:.85rem;padding:1rem;border-radius:8px;background:var(--svt-surface-2, rgba(0, 0, 0, .18));border:1px solid var(--svt-border, rgba(255, 255, 255, .08));margin-bottom:1rem}.discord-voice-hubs__hub-head{display:flex;align-items:center;justify-content:space-between;gap:1rem}.discord-voice-hubs__hub-title{display:flex;align-items:center;gap:var(--svt-space-2);margin:0;font-size:var(--svt-text-sm);font-weight:var(--svt-font-weight-semibold);color:var(--svt-text-primary)}.discord-voice-hubs__form-field{display:flex;flex-direction:column;gap:var(--svt-space-2)}.discord-voice-hubs__form-label{font-size:var(--svt-text-sm);font-weight:var(--svt-font-weight-medium);color:var(--svt-text-primary)}.discord-voice-hubs__form-helper{font-size:var(--svt-text-xs);color:var(--svt-text-tertiary);margin:0;line-height:1.5}.discord-voice-hubs__controls{display:flex;gap:var(--svt-gap-inner);align-items:center;flex-wrap:wrap}.discord-voice-hubs__controls svt-select{flex:1;min-width:220px}.discord-voice-hubs__empty{margin:0;padding:var(--svt-space-4);text-align:center;color:var(--svt-text-secondary);font-size:var(--svt-text-sm);font-style:italic;background:var(--svt-bg-tertiary);border:2px dashed var(--svt-border-primary);border-radius:var(--svt-radius-sm)}.discord-voice-hubs__role-list{display:flex;flex-wrap:wrap;gap:var(--svt-gap-inner)}.discord-voice-hubs__role-chip{display:inline-flex;align-items:center;gap:var(--svt-space-2);padding:var(--svt-space-1) var(--svt-space-3);background:var(--svt-bg-primary);border:1px solid var(--svt-border-primary);border-radius:var(--svt-radius-full);font-size:var(--svt-text-sm);color:var(--svt-text-primary)}.discord-voice-hubs__chip-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}.discord-voice-hubs__chip-remove{display:flex;align-items:center;justify-content:center;padding:0;background:transparent;border:none;cursor:pointer;color:var(--svt-text-secondary);border-radius:50%}.discord-voice-hubs__chip-remove:hover{color:var(--svt-error-500)}\n"] }]
    }], null, { clientId: [{
            type: Input
        }], canEdit: [{
            type: Input
        }], roles: [{
            type: Input
        }], hubs: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordVoiceHubsComponent, { className: "DiscordVoiceHubsComponent", filePath: "lib/components/discord-voice-hubs.component.ts", lineNumber: 41 }); })();

const _c0$3 = () => ({ standalone: true });
const _forTrack0$2 = ($index, $item) => $item.level;
function DiscordLevelingComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵelement(1, "svt-icon", 3);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 18);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.leveling.title"));
} }
function DiscordLevelingComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 1);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "common.loading"));
} }
function DiscordLevelingComponent_Conditional_6_Conditional_3_For_8_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 9)(1, "span", 17);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span", 1);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "svt-button", 18);
    i0.ɵɵlistener("click", function DiscordLevelingComponent_Conditional_6_Conditional_3_For_8_Template_svt_button_click_6_listener() { const reward_r5 = i0.ɵɵrestoreView(_r4).$implicit; const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.removeReward(reward_r5.level)); });
    i0.ɵɵelement(7, "svt-icon", 19);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const reward_r5 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate2("", i0.ɵɵpipeBind1(3, 4, "discord.leveling.level"), " ", reward_r5.level);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r1.roleName(reward_r5.roleId));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("size", 14);
} }
function DiscordLevelingComponent_Conditional_6_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "svt-input", 6);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵlistener("valueChange", function DiscordLevelingComponent_Conditional_6_Conditional_3_Template_svt_input_valueChange_1_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onMinLengthChange($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(3, "div", 7)(4, "h4", 8);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵrepeaterCreate(7, DiscordLevelingComponent_Conditional_6_Conditional_3_For_8_Template, 8, 6, "div", 9, _forTrack0$2);
    i0.ɵɵelementStart(9, "div", 10)(10, "svt-input", 11);
    i0.ɵɵpipe(11, "localize");
    i0.ɵɵlistener("valueChange", function DiscordLevelingComponent_Conditional_6_Conditional_3_Template_svt_input_valueChange_10_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.newRewardLevel.set(+$event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "svt-select", 12);
    i0.ɵɵpipe(13, "localize");
    i0.ɵɵlistener("onSelect", function DiscordLevelingComponent_Conditional_6_Conditional_3_Template_svt_select_onSelect_12_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.newRewardRoleId.set(($event == null ? null : $event.value) ?? "")); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "svt-button", 13);
    i0.ɵɵlistener("click", function DiscordLevelingComponent_Conditional_6_Conditional_3_Template_svt_button_click_14_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.addReward()); });
    i0.ɵɵelement(15, "svt-icon", 14);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(16, "div", 15)(17, "svt-button", 16);
    i0.ɵɵlistener("click", function DiscordLevelingComponent_Conditional_6_Conditional_3_Template_svt_button_click_17_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.save()); });
    i0.ɵɵtext(18);
    i0.ɵɵpipe(19, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 14, "discord.leveling.minLength"))("ngModel", ctx_r1.cfg().minMessageLength)("ngModelOptions", i0.ɵɵpureFunction0(24, _c0$3));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 16, "discord.leveling.rewardsTitle"));
    i0.ɵɵadvance(2);
    i0.ɵɵrepeater(ctx_r1.cfg().rewards);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(11, 18, "discord.leveling.rewardLevel"))("ngModel", ctx_r1.newRewardLevel())("ngModelOptions", i0.ɵɵpureFunction0(25, _c0$3));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(13, 20, "discord.leveling.rewardRole"))("options", ctx_r1.roleOptions())("ngModel", ctx_r1.newRewardOption())("ngModelOptions", i0.ɵɵpureFunction0(26, _c0$3));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("size", 14);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("loading", ctx_r1.saving());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(19, 22, ctx_r1.saving() ? "common.saving" : "common.save"), " ");
} }
function DiscordLevelingComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "svt-toggle", 5);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵlistener("toggleChange", function DiscordLevelingComponent_Conditional_6_Template_svt_toggle_toggleChange_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggleEnabled($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵconditionalCreate(3, DiscordLevelingComponent_Conditional_6_Conditional_3_Template, 20, 27);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r1.cfg().enabled)("label", i0.ɵɵpipeBind1(2, 3, "discord.leveling.enable"));
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.cfg().enabled ? 3 : -1);
} }
class DiscordLevelingComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k, p) => this.i18n.translate(k, p);
        this.clientId = '';
        this.roles = [];
        this.loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
        this.saving = signal(false, ...(ngDevMode ? [{ debugName: "saving" }] : []));
        this._cfg = signal(null, ...(ngDevMode ? [{ debugName: "_cfg" }] : []));
        this.cfg = computed(() => this._cfg(), ...(ngDevMode ? [{ debugName: "cfg" }] : []));
        this.newRewardLevel = signal(1, ...(ngDevMode ? [{ debugName: "newRewardLevel" }] : []));
        this.newRewardRoleId = signal('', ...(ngDevMode ? [{ debugName: "newRewardRoleId" }] : []));
        this.roleOptions = computed(() => this.roles.map(r => ({ value: r.id, label: r.name })), ...(ngDevMode ? [{ debugName: "roleOptions" }] : []));
        this.newRewardOption = computed(() => this.roleOptions().find(o => o.value === this.newRewardRoleId()) ?? null, ...(ngDevMode ? [{ debugName: "newRewardOption" }] : []));
    }
    ngOnChanges() {
        if (this.clientId)
            this.load();
    }
    load() {
        this.loading.set(true);
        this.port.getLevelingConfig(this.clientId).subscribe({
            next: cfg => { this._cfg.set(cfg); this.loading.set(false); },
            error: () => this.loading.set(false),
        });
    }
    toggleEnabled(enabled) {
        const cur = this._cfg();
        if (!cur)
            return;
        this._cfg.set({ ...cur, enabled });
    }
    onMinLengthChange(val) {
        const cur = this._cfg();
        if (!cur)
            return;
        this._cfg.set({ ...cur, minMessageLength: Math.max(1, +val || 1) });
    }
    addReward() {
        const cur = this._cfg();
        if (!cur || !this.newRewardRoleId() || this.newRewardLevel() < 1)
            return;
        const existing = cur.rewards.find(r => r.level === this.newRewardLevel());
        if (existing)
            return;
        this._cfg.set({ ...cur, rewards: [...cur.rewards, { level: this.newRewardLevel(), roleId: this.newRewardRoleId() }] });
    }
    removeReward(level) {
        const cur = this._cfg();
        if (!cur)
            return;
        this._cfg.set({ ...cur, rewards: cur.rewards.filter(r => r.level !== level) });
    }
    roleName(roleId) {
        return this.roles.find(r => r.id === roleId)?.name || roleId;
    }
    save() {
        const cur = this._cfg();
        if (!cur || this.saving())
            return;
        this.saving.set(true);
        this.port.updateLevelingConfig(this.clientId, cur).subscribe({
            next: () => {
                this.saving.set(false);
                this.toastr.success(this.t('common.success'), this.t('discord.leveling.saved'));
            },
            error: () => {
                this.saving.set(false);
                this.toastr.error(this.t('common.error'), this.t('discord.leveling.saveFailed'));
            },
        });
    }
    static { this.ɵfac = function DiscordLevelingComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordLevelingComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordLevelingComponent, selectors: [["svt-discord-leveling"]], inputs: { clientId: "clientId", roles: "roles" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 4, consts: [["svtCardHeader", ""], [1, "svt-text-muted"], [1, "svt-card-header-row"], ["name", "trending-up", 3, "size"], [1, "svt-form-row"], [3, "toggleChange", "checked", "label"], ["type", "number", 3, "valueChange", "label", "ngModel", "ngModelOptions"], [1, "svt-form-section"], [1, "svt-label"], [1, "svt-row", "svt-row--gap"], [1, "svt-row", "svt-row--gap", 2, "margin-top", "8px"], ["type", "number", 2, "width", "80px", 3, "valueChange", "label", "ngModel", "ngModelOptions"], [3, "onSelect", "label", "options", "ngModel", "ngModelOptions"], ["variant", "secondary", "size", "small", 3, "click"], ["name", "plus", 3, "size"], [1, "svt-form-actions"], ["variant", "primary", 3, "click", "loading"], [1, "svt-text-sm"], ["variant", "ghost", "size", "small", 3, "click"], ["name", "trash-2", 3, "size"]], template: function DiscordLevelingComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card");
            i0.ɵɵtemplate(1, DiscordLevelingComponent_ng_template_1_Template, 5, 4, "ng-template", 0);
            i0.ɵɵelementStart(2, "p", 1);
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(5, DiscordLevelingComponent_Conditional_5_Template, 3, 3, "p", 1)(6, DiscordLevelingComponent_Conditional_6_Template, 4, 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.leveling.description"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.loading() ? 5 : ctx.cfg() ? 6 : -1);
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtButtonComponent,
            SvtInputComponent,
            SvtIconComponent,
            SvtToggleComponent,
            SvtSelectComponent,
            LocalizePipe], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordLevelingComponent, [{
        type: Component,
        args: [{
                selector: 'svt-discord-leveling',
                standalone: true,
                imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtButtonComponent,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtToggleComponent,
                    SvtSelectComponent,
                    LocalizePipe,
                ],
                template: `
    <svt-card>
      <ng-template svtCardHeader>
        <div class="svt-card-header-row">
          <svt-icon name="trending-up" [size]="18"/>
          <span>{{ 'discord.leveling.title' | localize }}</span>
        </div>
      </ng-template>

      <p class="svt-text-muted">{{ 'discord.leveling.description' | localize }}</p>

      @if (loading()) {
        <p class="svt-text-muted">{{ 'common.loading' | localize }}</p>
      } @else if (cfg()) {
        <div class="svt-form-row">
          <svt-toggle
            [checked]="cfg()!.enabled"
            [label]="'discord.leveling.enable' | localize"
            (toggleChange)="toggleEnabled($event)"
          />
        </div>

        @if (cfg()!.enabled) {
          <div class="svt-form-row">
            <svt-input
              [label]="'discord.leveling.minLength' | localize"
              type="number"
              [ngModel]="cfg()!.minMessageLength"
              [ngModelOptions]="{ standalone: true }"
              (valueChange)="onMinLengthChange($event)"
            />
          </div>

          <div class="svt-form-section">
            <h4 class="svt-label">{{ 'discord.leveling.rewardsTitle' | localize }}</h4>
            @for (reward of cfg()!.rewards; track reward.level) {
              <div class="svt-row svt-row--gap">
                <span class="svt-text-sm">{{ 'discord.leveling.level' | localize }} {{ reward.level }}</span>
                <span class="svt-text-muted">{{ roleName(reward.roleId) }}</span>
                <svt-button variant="ghost" size="small" (click)="removeReward(reward.level)">
                  <svt-icon name="trash-2" [size]="14"/>
                </svt-button>
              </div>
            }
            <div class="svt-row svt-row--gap" style="margin-top:8px">
              <svt-input
                [label]="'discord.leveling.rewardLevel' | localize"
                type="number"
                [ngModel]="newRewardLevel()"
                [ngModelOptions]="{ standalone: true }"
                (valueChange)="newRewardLevel.set(+$event)"
                style="width:80px"
              />
              <svt-select
                [label]="'discord.leveling.rewardRole' | localize"
                [options]="roleOptions()"
                [ngModel]="newRewardOption()"
                [ngModelOptions]="{ standalone: true }"
                (onSelect)="newRewardRoleId.set($event?.value ?? '')"
              />
              <svt-button variant="secondary" size="small" (click)="addReward()">
                <svt-icon name="plus" [size]="14"/>
              </svt-button>
            </div>
          </div>

          <div class="svt-form-actions">
            <svt-button variant="primary" [loading]="saving()" (click)="save()">
              {{ (saving() ? 'common.saving' : 'common.save') | localize }}
            </svt-button>
          </div>
        }
      }
    </svt-card>
  `,
            }]
    }], null, { clientId: [{
            type: Input
        }], roles: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordLevelingComponent, { className: "DiscordLevelingComponent", filePath: "lib/components/discord-leveling.component.ts", lineNumber: 110 }); })();

const _c0$2 = () => ({ standalone: true });
const _forTrack0$1 = ($index, $item) => $item._id;
function DiscordReactionRolesComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵelement(1, "svt-icon", 3);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 18);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.reactionRoles.title"));
} }
function DiscordReactionRolesComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 1);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "common.loading"));
} }
function DiscordReactionRolesComponent_Conditional_6_For_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "div")(2, "strong");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span", 17);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(7, "svt-button", 18);
    i0.ɵɵlistener("click", function DiscordReactionRolesComponent_Conditional_6_For_1_Template_svt_button_click_7_listener() { const panel_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r3.deletePanel(panel_r3._id)); });
    i0.ɵɵelement(8, "svt-icon", 19);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const panel_r3 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(panel_r3.title);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate3("", " \u2014 ", "", panel_r3.mappings.length, " ", i0.ɵɵpipeBind1(6, 6, "discord.reactionRoles.roles"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("loading", ctx_r3.deleting() === panel_r3._id);
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 14);
} }
function DiscordReactionRolesComponent_Conditional_6_For_18_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 10)(1, "span", 20);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "span", 1);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "svt-button", 21);
    i0.ɵɵlistener("click", function DiscordReactionRolesComponent_Conditional_6_For_18_Template_svt_button_click_5_listener() { const $index_r6 = i0.ɵɵrestoreView(_r5).$index; const ctx_r3 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r3.removeMapping($index_r6)); });
    i0.ɵɵelement(6, "svt-icon", 22);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const m_r7 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r3.roleName(m_r7.roleId));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(m_r7.label);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("size", 12);
} }
function DiscordReactionRolesComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵrepeaterCreate(0, DiscordReactionRolesComponent_Conditional_6_For_1_Template, 9, 8, "div", 4, _forTrack0$1);
    i0.ɵɵelementStart(2, "div", 5)(3, "h4", 6);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "svt-select", 7);
    i0.ɵɵpipe(7, "localize");
    i0.ɵɵlistener("onSelect", function DiscordReactionRolesComponent_Conditional_6_Template_svt_select_onSelect_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.newChannelId.set(($event == null ? null : $event.value) ?? "")); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "svt-input", 8);
    i0.ɵɵpipe(9, "localize");
    i0.ɵɵpipe(10, "localize");
    i0.ɵɵlistener("valueChange", function DiscordReactionRolesComponent_Conditional_6_Template_svt_input_valueChange_8_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.newTitle.set($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "svt-input", 8);
    i0.ɵɵpipe(12, "localize");
    i0.ɵɵpipe(13, "localize");
    i0.ɵɵlistener("valueChange", function DiscordReactionRolesComponent_Conditional_6_Template_svt_input_valueChange_11_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.newDescription.set($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "h5", 9);
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵrepeaterCreate(17, DiscordReactionRolesComponent_Conditional_6_For_18_Template, 7, 3, "div", 10, i0.ɵɵrepeaterTrackByIndex);
    i0.ɵɵelementStart(19, "div", 11)(20, "svt-select", 7);
    i0.ɵɵpipe(21, "localize");
    i0.ɵɵlistener("onSelect", function DiscordReactionRolesComponent_Conditional_6_Template_svt_select_onSelect_20_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.addRoleId.set(($event == null ? null : $event.value) ?? "")); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(22, "svt-input", 12);
    i0.ɵɵpipe(23, "localize");
    i0.ɵɵlistener("valueChange", function DiscordReactionRolesComponent_Conditional_6_Template_svt_input_valueChange_22_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.addLabel.set($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(24, "svt-button", 13);
    i0.ɵɵlistener("click", function DiscordReactionRolesComponent_Conditional_6_Template_svt_button_click_24_listener() { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.addMapping()); });
    i0.ɵɵelement(25, "svt-icon", 14);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(26, "div", 15)(27, "svt-button", 16);
    i0.ɵɵlistener("click", function DiscordReactionRolesComponent_Conditional_6_Template_svt_button_click_27_listener() { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.createPanel()); });
    i0.ɵɵtext(28);
    i0.ɵɵpipe(29, "localize");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r3.panels());
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 24, "discord.reactionRoles.newPanel"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(7, 26, "discord.reactionRoles.channel"))("options", ctx_r3.channelOptions())("ngModel", ctx_r3.selectedChannelOption())("ngModelOptions", i0.ɵɵpureFunction0(44, _c0$2));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(9, 28, "discord.reactionRoles.panelTitle"))("ngModel", ctx_r3.newTitle())("ngModelOptions", i0.ɵɵpureFunction0(45, _c0$2))("placeholder", i0.ɵɵpipeBind1(10, 30, "discord.reactionRoles.panelTitlePlaceholder"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(12, 32, "discord.reactionRoles.panelDescription"))("ngModel", ctx_r3.newDescription())("ngModelOptions", i0.ɵɵpureFunction0(46, _c0$2))("placeholder", i0.ɵɵpipeBind1(13, 34, "discord.reactionRoles.panelDescPlaceholder"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 36, "discord.reactionRoles.mappings"));
    i0.ɵɵadvance(2);
    i0.ɵɵrepeater(ctx_r3.pendingMappings());
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(21, 38, "discord.reactionRoles.role"))("options", ctx_r3.roleOptions())("ngModel", ctx_r3.selectedAddRoleOption())("ngModelOptions", i0.ɵɵpureFunction0(47, _c0$2));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(23, 40, "discord.reactionRoles.buttonLabel"))("ngModel", ctx_r3.addLabel())("ngModelOptions", i0.ɵɵpureFunction0(48, _c0$2));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("size", 14);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("loading", ctx_r3.creating());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(29, 42, ctx_r3.creating() ? "common.saving" : "discord.reactionRoles.post"), " ");
} }
class DiscordReactionRolesComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k) => this.i18n.translate(k);
        this.clientId = '';
        this.roles = [];
        this.channels = [];
        this.loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
        this.creating = signal(false, ...(ngDevMode ? [{ debugName: "creating" }] : []));
        this.deleting = signal(null, ...(ngDevMode ? [{ debugName: "deleting" }] : []));
        this._panels = signal([], ...(ngDevMode ? [{ debugName: "_panels" }] : []));
        this.panels = computed(() => this._panels(), ...(ngDevMode ? [{ debugName: "panels" }] : []));
        this.newChannelId = signal('', ...(ngDevMode ? [{ debugName: "newChannelId" }] : []));
        this.newTitle = signal('', ...(ngDevMode ? [{ debugName: "newTitle" }] : []));
        this.newDescription = signal('', ...(ngDevMode ? [{ debugName: "newDescription" }] : []));
        this.pendingMappings = signal([], ...(ngDevMode ? [{ debugName: "pendingMappings" }] : []));
        this.addRoleId = signal('', ...(ngDevMode ? [{ debugName: "addRoleId" }] : []));
        this.addLabel = signal('', ...(ngDevMode ? [{ debugName: "addLabel" }] : []));
        this.roleOptions = computed(() => this.roles.map(r => ({ value: r.id, label: r.name })), ...(ngDevMode ? [{ debugName: "roleOptions" }] : []));
        this.channelOptions = computed(() => this.channels.filter(c => c.type === 0).map(c => ({ value: c.id, label: `#${c.name}` })), ...(ngDevMode ? [{ debugName: "channelOptions" }] : []));
        this.selectedChannelOption = computed(() => this.channelOptions().find(o => o.value === this.newChannelId()) ?? null, ...(ngDevMode ? [{ debugName: "selectedChannelOption" }] : []));
        this.selectedAddRoleOption = computed(() => this.roleOptions().find(o => o.value === this.addRoleId()) ?? null, ...(ngDevMode ? [{ debugName: "selectedAddRoleOption" }] : []));
    }
    ngOnChanges() {
        if (this.clientId)
            this.load();
    }
    load() {
        this.loading.set(true);
        this.port.getReactionPanels(this.clientId).subscribe({
            next: p => { this._panels.set(p); this.loading.set(false); },
            error: () => this.loading.set(false),
        });
    }
    roleName(roleId) {
        return this.roles.find(r => r.id === roleId)?.name || roleId;
    }
    addMapping() {
        if (!this.addRoleId() || !this.addLabel())
            return;
        this.pendingMappings.set([...this.pendingMappings(), { roleId: this.addRoleId(), label: this.addLabel() }]);
        this.addRoleId.set('');
        this.addLabel.set('');
    }
    removeMapping(idx) {
        this.pendingMappings.set(this.pendingMappings().filter((_, i) => i !== idx));
    }
    createPanel() {
        if (!this.newChannelId() || !this.newTitle() || this.pendingMappings().length === 0 || this.creating())
            return;
        this.creating.set(true);
        this.port.createReactionPanel(this.clientId, {
            channelId: this.newChannelId(),
            title: this.newTitle(),
            description: this.newDescription(),
            mappings: this.pendingMappings(),
        }).subscribe({
            next: res => {
                this.creating.set(false);
                this._panels.set([...this._panels(), res.panel]);
                this.newTitle.set('');
                this.newDescription.set('');
                this.pendingMappings.set([]);
                this.toastr.success(this.t('common.success'), this.t('discord.reactionRoles.panelCreated'));
            },
            error: () => {
                this.creating.set(false);
                this.toastr.error(this.t('common.error'), this.t('discord.reactionRoles.panelFailed'));
            },
        });
    }
    deletePanel(panelId) {
        if (this.deleting())
            return;
        this.deleting.set(panelId);
        this.port.deleteReactionPanel(this.clientId, panelId).subscribe({
            next: () => {
                this.deleting.set(null);
                this._panels.set(this._panels().filter(p => p._id !== panelId));
                this.toastr.success(this.t('common.success'), this.t('discord.reactionRoles.panelDeleted'));
            },
            error: () => {
                this.deleting.set(null);
                this.toastr.error(this.t('common.error'), this.t('discord.reactionRoles.panelDeleteFailed'));
            },
        });
    }
    static { this.ɵfac = function DiscordReactionRolesComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordReactionRolesComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordReactionRolesComponent, selectors: [["svt-discord-reaction-roles"]], inputs: { clientId: "clientId", roles: "roles", channels: "channels" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 4, consts: [["svtCardHeader", ""], [1, "svt-text-muted"], [1, "svt-card-header-row"], ["name", "check-square", 3, "size"], [1, "svt-panel-row"], [1, "svt-form-section", 2, "margin-top", "16px"], [1, "svt-label"], [3, "onSelect", "label", "options", "ngModel", "ngModelOptions"], [3, "valueChange", "label", "ngModel", "ngModelOptions", "placeholder"], [1, "svt-label", 2, "margin-top", "8px"], [1, "svt-row", "svt-row--gap"], [1, "svt-row", "svt-row--gap", 2, "margin-top", "6px"], [2, "width", "140px", 3, "valueChange", "label", "ngModel", "ngModelOptions"], ["variant", "secondary", "size", "small", 3, "click"], ["name", "plus", 3, "size"], [1, "svt-form-actions", 2, "margin-top", "12px"], ["variant", "primary", 3, "click", "loading"], [1, "svt-text-muted", "svt-text-sm"], ["variant", "ghost", "size", "small", 3, "click", "loading"], ["name", "trash-2", 3, "size"], [1, "svt-text-sm"], ["variant", "ghost", "size", "small", 3, "click"], ["name", "x", 3, "size"]], template: function DiscordReactionRolesComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card");
            i0.ɵɵtemplate(1, DiscordReactionRolesComponent_ng_template_1_Template, 5, 4, "ng-template", 0);
            i0.ɵɵelementStart(2, "p", 1);
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(5, DiscordReactionRolesComponent_Conditional_5_Template, 3, 3, "p", 1)(6, DiscordReactionRolesComponent_Conditional_6_Template, 30, 49);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.reactionRoles.description"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.loading() ? 5 : 6);
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtButtonComponent,
            SvtInputComponent,
            SvtIconComponent,
            SvtSelectComponent,
            LocalizePipe], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordReactionRolesComponent, [{
        type: Component,
        args: [{
                selector: 'svt-discord-reaction-roles',
                standalone: true,
                imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtButtonComponent,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtSelectComponent,
                    LocalizePipe,
                ],
                template: `
    <svt-card>
      <ng-template svtCardHeader>
        <div class="svt-card-header-row">
          <svt-icon name="check-square" [size]="18"/>
          <span>{{ 'discord.reactionRoles.title' | localize }}</span>
        </div>
      </ng-template>

      <p class="svt-text-muted">{{ 'discord.reactionRoles.description' | localize }}</p>

      @if (loading()) {
        <p class="svt-text-muted">{{ 'common.loading' | localize }}</p>
      } @else {
        <!-- Existing panels -->
        @for (panel of panels(); track panel._id) {
          <div class="svt-panel-row">
            <div>
              <strong>{{ panel.title }}</strong>
              <span class="svt-text-muted svt-text-sm">{{ ' — ' }}{{ panel.mappings.length }} {{ 'discord.reactionRoles.roles' | localize }}</span>
            </div>
            <svt-button variant="ghost" size="small" [loading]="deleting() === panel._id" (click)="deletePanel(panel._id)">
              <svt-icon name="trash-2" [size]="14"/>
            </svt-button>
          </div>
        }

        <!-- Create new panel -->
        <div class="svt-form-section" style="margin-top:16px">
          <h4 class="svt-label">{{ 'discord.reactionRoles.newPanel' | localize }}</h4>
          <svt-select
            [label]="'discord.reactionRoles.channel' | localize"
            [options]="channelOptions()"
            [ngModel]="selectedChannelOption()"
            [ngModelOptions]="{ standalone: true }"
            (onSelect)="newChannelId.set($event?.value ?? '')"
          />
          <svt-input
            [label]="'discord.reactionRoles.panelTitle' | localize"
            [ngModel]="newTitle()"
            [ngModelOptions]="{ standalone: true }"
            (valueChange)="newTitle.set($event)"
            [placeholder]="'discord.reactionRoles.panelTitlePlaceholder' | localize"
          />
          <svt-input
            [label]="'discord.reactionRoles.panelDescription' | localize"
            [ngModel]="newDescription()"
            [ngModelOptions]="{ standalone: true }"
            (valueChange)="newDescription.set($event)"
            [placeholder]="'discord.reactionRoles.panelDescPlaceholder' | localize"
          />

          <!-- Mapping rows -->
          <h5 class="svt-label" style="margin-top:8px">{{ 'discord.reactionRoles.mappings' | localize }}</h5>
          @for (m of pendingMappings(); track $index) {
            <div class="svt-row svt-row--gap">
              <span class="svt-text-sm">{{ roleName(m.roleId) }}</span>
              <span class="svt-text-muted">{{ m.label }}</span>
              <svt-button variant="ghost" size="small" (click)="removeMapping($index)">
                <svt-icon name="x" [size]="12"/>
              </svt-button>
            </div>
          }
          <div class="svt-row svt-row--gap" style="margin-top:6px">
            <svt-select
              [label]="'discord.reactionRoles.role' | localize"
              [options]="roleOptions()"
              [ngModel]="selectedAddRoleOption()"
              [ngModelOptions]="{ standalone: true }"
              (onSelect)="addRoleId.set($event?.value ?? '')"
            />
            <svt-input
              [label]="'discord.reactionRoles.buttonLabel' | localize"
              [ngModel]="addLabel()"
              [ngModelOptions]="{ standalone: true }"
              (valueChange)="addLabel.set($event)"
              style="width:140px"
            />
            <svt-button variant="secondary" size="small" (click)="addMapping()">
              <svt-icon name="plus" [size]="14"/>
            </svt-button>
          </div>

          <div class="svt-form-actions" style="margin-top:12px">
            <svt-button variant="primary" [loading]="creating()" (click)="createPanel()">
              {{ (creating() ? 'common.saving' : 'discord.reactionRoles.post') | localize }}
            </svt-button>
          </div>
        </div>
      }
    </svt-card>
  `,
            }]
    }], null, { clientId: [{
            type: Input
        }], roles: [{
            type: Input
        }], channels: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordReactionRolesComponent, { className: "DiscordReactionRolesComponent", filePath: "lib/components/discord-reaction-roles.component.ts", lineNumber: 127 }); })();

const _c0$1 = () => ({ standalone: true });
function DiscordStatsComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵelement(1, "svt-icon", 3);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 18);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.stats.title"));
} }
function DiscordStatsComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 1);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "common.loading"));
} }
function DiscordStatsComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "svt-select", 4);
    i0.ɵɵpipe(1, "localize");
    i0.ɵɵlistener("onSelect", function DiscordStatsComponent_Conditional_6_Template_svt_select_onSelect_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onMemberChannelChange($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "svt-input", 5);
    i0.ɵɵpipe(3, "localize");
    i0.ɵɵlistener("valueChange", function DiscordStatsComponent_Conditional_6_Template_svt_input_valueChange_2_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onTemplateChange("member", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "p", 6);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "svt-select", 7);
    i0.ɵɵpipe(8, "localize");
    i0.ɵɵlistener("onSelect", function DiscordStatsComponent_Conditional_6_Template_svt_select_onSelect_7_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onOnlineChannelChange($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "svt-input", 5);
    i0.ɵɵpipe(10, "localize");
    i0.ɵɵlistener("valueChange", function DiscordStatsComponent_Conditional_6_Template_svt_input_valueChange_9_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onTemplateChange("online", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "p", 8);
    i0.ɵɵtext(12);
    i0.ɵɵpipe(13, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "div", 9)(15, "svt-button", 10);
    i0.ɵɵlistener("click", function DiscordStatsComponent_Conditional_6_Template_svt_button_click_15_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.save()); });
    i0.ɵɵtext(16);
    i0.ɵɵpipe(17, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 20, "discord.stats.memberChannel"))("options", ctx_r1.voiceChannelOptions())("ngModel", ctx_r1.selectedMemberChannelOption())("ngModelOptions", i0.ɵɵpureFunction0(34, _c0$1));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(3, 22, "discord.stats.memberTemplate"))("ngModel", ctx_r1.cfg().memberCountTemplate)("ngModelOptions", i0.ɵɵpureFunction0(35, _c0$1))("placeholder", "Members: {count}");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 24, "discord.stats.templateHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(8, 26, "discord.stats.onlineChannel"))("options", ctx_r1.voiceChannelOptions())("ngModel", ctx_r1.selectedOnlineChannelOption())("ngModelOptions", i0.ɵɵpureFunction0(36, _c0$1));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(10, 28, "discord.stats.onlineTemplate"))("ngModel", ctx_r1.cfg().onlineCountTemplate)("ngModelOptions", i0.ɵɵpureFunction0(37, _c0$1))("placeholder", "Online: {count}");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(13, 30, "discord.stats.rateHint"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("loading", ctx_r1.saving());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(17, 32, ctx_r1.saving() ? "common.saving" : "common.save"), " ");
} }
class DiscordStatsComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k) => this.i18n.translate(k);
        this.clientId = '';
        this.channels = [];
        this.loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
        this.saving = signal(false, ...(ngDevMode ? [{ debugName: "saving" }] : []));
        this._cfg = signal(null, ...(ngDevMode ? [{ debugName: "_cfg" }] : []));
        this.cfg = computed(() => this._cfg(), ...(ngDevMode ? [{ debugName: "cfg" }] : []));
        // Discord voice channels (type 2)
        this.voiceChannelOptions = computed(() => [
            { value: '', label: this.t('discord.stats.noChannel') },
            ...this.channels.filter(c => c.type === 2).map(c => ({ value: c.id, label: c.name })),
        ], ...(ngDevMode ? [{ debugName: "voiceChannelOptions" }] : []));
        this.selectedMemberChannelOption = computed(() => this.voiceChannelOptions().find(o => o.value === (this._cfg()?.memberCountChannelId ?? '')) ?? null, ...(ngDevMode ? [{ debugName: "selectedMemberChannelOption" }] : []));
        this.selectedOnlineChannelOption = computed(() => this.voiceChannelOptions().find(o => o.value === (this._cfg()?.onlineCountChannelId ?? '')) ?? null, ...(ngDevMode ? [{ debugName: "selectedOnlineChannelOption" }] : []));
    }
    ngOnChanges() {
        if (this.clientId)
            this.load();
    }
    load() {
        this.loading.set(true);
        this.port.getStatsChannels(this.clientId).subscribe({
            next: cfg => { this._cfg.set(cfg); this.loading.set(false); },
            error: () => this.loading.set(false),
        });
    }
    onMemberChannelChange(opt) {
        const cur = this._cfg();
        if (!cur)
            return;
        this._cfg.set({ ...cur, memberCountChannelId: opt?.value || null });
    }
    onOnlineChannelChange(opt) {
        const cur = this._cfg();
        if (!cur)
            return;
        this._cfg.set({ ...cur, onlineCountChannelId: opt?.value || null });
    }
    onTemplateChange(field, val) {
        const cur = this._cfg();
        if (!cur)
            return;
        if (field === 'member')
            this._cfg.set({ ...cur, memberCountTemplate: val });
        else
            this._cfg.set({ ...cur, onlineCountTemplate: val });
    }
    save() {
        const cur = this._cfg();
        if (!cur || this.saving())
            return;
        this.saving.set(true);
        this.port.updateStatsChannels(this.clientId, cur).subscribe({
            next: () => {
                this.saving.set(false);
                this.toastr.success(this.t('common.success'), this.t('discord.stats.saved'));
            },
            error: () => {
                this.saving.set(false);
                this.toastr.error(this.t('common.error'), this.t('discord.stats.saveFailed'));
            },
        });
    }
    static { this.ɵfac = function DiscordStatsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordStatsComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordStatsComponent, selectors: [["svt-discord-stats"]], inputs: { clientId: "clientId", channels: "channels" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 4, consts: [["svtCardHeader", ""], [1, "svt-text-muted"], [1, "svt-card-header-row"], ["name", "bar-chart-2", 3, "size"], [3, "onSelect", "label", "options", "ngModel", "ngModelOptions"], [3, "valueChange", "label", "ngModel", "ngModelOptions", "placeholder"], [1, "svt-text-hint"], [2, "margin-top", "12px", 3, "onSelect", "label", "options", "ngModel", "ngModelOptions"], [1, "svt-text-hint", 2, "margin-top", "8px"], [1, "svt-form-actions"], ["variant", "primary", 3, "click", "loading"]], template: function DiscordStatsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card");
            i0.ɵɵtemplate(1, DiscordStatsComponent_ng_template_1_Template, 5, 4, "ng-template", 0);
            i0.ɵɵelementStart(2, "p", 1);
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(5, DiscordStatsComponent_Conditional_5_Template, 3, 3, "p", 1)(6, DiscordStatsComponent_Conditional_6_Template, 18, 38);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.stats.description"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.loading() ? 5 : ctx.cfg() ? 6 : -1);
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtButtonComponent,
            SvtInputComponent,
            SvtIconComponent,
            SvtSelectComponent,
            LocalizePipe], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordStatsComponent, [{
        type: Component,
        args: [{
                selector: 'svt-discord-stats',
                standalone: true,
                imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtButtonComponent,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtSelectComponent,
                    LocalizePipe,
                ],
                template: `
    <svt-card>
      <ng-template svtCardHeader>
        <div class="svt-card-header-row">
          <svt-icon name="bar-chart-2" [size]="18"/>
          <span>{{ 'discord.stats.title' | localize }}</span>
        </div>
      </ng-template>

      <p class="svt-text-muted">{{ 'discord.stats.description' | localize }}</p>

      @if (loading()) {
        <p class="svt-text-muted">{{ 'common.loading' | localize }}</p>
      } @else if (cfg()) {
        <svt-select
          [label]="'discord.stats.memberChannel' | localize"
          [options]="voiceChannelOptions()"
          [ngModel]="selectedMemberChannelOption()"
          [ngModelOptions]="{ standalone: true }"
          (onSelect)="onMemberChannelChange($event)"
        />
        <svt-input
          [label]="'discord.stats.memberTemplate' | localize"
          [ngModel]="cfg()!.memberCountTemplate"
          [ngModelOptions]="{ standalone: true }"
          (valueChange)="onTemplateChange('member', $event)"
          [placeholder]="'Members: {count}'"
        />
        <p class="svt-text-hint">{{ 'discord.stats.templateHint' | localize }}</p>

        <svt-select
          [label]="'discord.stats.onlineChannel' | localize"
          [options]="voiceChannelOptions()"
          [ngModel]="selectedOnlineChannelOption()"
          [ngModelOptions]="{ standalone: true }"
          (onSelect)="onOnlineChannelChange($event)"
          style="margin-top:12px"
        />
        <svt-input
          [label]="'discord.stats.onlineTemplate' | localize"
          [ngModel]="cfg()!.onlineCountTemplate"
          [ngModelOptions]="{ standalone: true }"
          (valueChange)="onTemplateChange('online', $event)"
          [placeholder]="'Online: {count}'"
        />

        <p class="svt-text-hint" style="margin-top:8px">{{ 'discord.stats.rateHint' | localize }}</p>

        <div class="svt-form-actions">
          <svt-button variant="primary" [loading]="saving()" (click)="save()">
            {{ (saving() ? 'common.saving' : 'common.save') | localize }}
          </svt-button>
        </div>
      }
    </svt-card>
  `,
            }]
    }], null, { clientId: [{
            type: Input
        }], channels: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordStatsComponent, { className: "DiscordStatsComponent", filePath: "lib/components/discord-stats.component.ts", lineNumber: 89 }); })();

function DiscordAutomodComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵelement(1, "svt-icon", 3);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 18);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.automod.title"));
} }
function DiscordAutomodComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 1);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "common.loading"));
} }
function DiscordAutomodComponent_Conditional_6_Conditional_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 7);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.errorMsg());
} }
function DiscordAutomodComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "svt-toggle", 5);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵlistener("toggleChange", function DiscordAutomodComponent_Conditional_6_Template_svt_toggle_toggleChange_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggle("linkFilter", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "p", 6);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "svt-toggle", 5);
    i0.ɵɵpipe(7, "localize");
    i0.ɵɵlistener("toggleChange", function DiscordAutomodComponent_Conditional_6_Template_svt_toggle_toggleChange_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggle("spamFilter", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "p", 6);
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "svt-toggle", 5);
    i0.ɵɵpipe(12, "localize");
    i0.ɵɵlistener("toggleChange", function DiscordAutomodComponent_Conditional_6_Template_svt_toggle_toggleChange_11_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggle("mentionSpam", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "p", 6);
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "localize");
    i0.ɵɵelementEnd()();
    i0.ɵɵconditionalCreate(16, DiscordAutomodComponent_Conditional_6_Conditional_16_Template, 2, 1, "p", 7);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r1.cfg().linkFilter)("label", i0.ɵɵpipeBind1(2, 10, "discord.automod.linkFilter"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 12, "discord.automod.linkFilterHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("checked", ctx_r1.cfg().spamFilter)("label", i0.ɵɵpipeBind1(7, 14, "discord.automod.spamFilter"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 16, "discord.automod.spamFilterHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("checked", ctx_r1.cfg().mentionSpam)("label", i0.ɵɵpipeBind1(12, 18, "discord.automod.mentionSpam"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(15, 20, "discord.automod.mentionSpamHint"));
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.errorMsg() ? 16 : -1);
} }
class DiscordAutomodComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k) => this.i18n.translate(k);
        this.clientId = '';
        this.loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
        this._cfg = signal(null, ...(ngDevMode ? [{ debugName: "_cfg" }] : []));
        this.cfg = computed(() => this._cfg(), ...(ngDevMode ? [{ debugName: "cfg" }] : []));
        this.errorMsg = signal(null, ...(ngDevMode ? [{ debugName: "errorMsg" }] : []));
    }
    ngOnChanges() {
        if (this.clientId)
            this.load();
    }
    load() {
        this.loading.set(true);
        this.port.getAutomodConfig(this.clientId).subscribe({
            next: cfg => { this._cfg.set(cfg); this.loading.set(false); },
            error: () => this.loading.set(false),
        });
    }
    toggle(rule, enabled) {
        this.errorMsg.set(null);
        this.port.updateAutomodConfig(this.clientId, { [rule]: enabled }).subscribe({
            next: () => {
                const cur = this._cfg();
                if (cur)
                    this._cfg.set({ ...cur, [rule]: enabled });
                this.toastr.success(this.t('common.success'), this.t('discord.automod.saved'));
            },
            error: (err) => {
                const msg = err?.error?.message || this.t('discord.automod.saveFailed');
                this.errorMsg.set(msg);
                this.toastr.error(this.t('common.error'), msg);
            },
        });
    }
    static { this.ɵfac = function DiscordAutomodComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordAutomodComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordAutomodComponent, selectors: [["svt-discord-automod"]], inputs: { clientId: "clientId" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 4, consts: [["svtCardHeader", ""], [1, "svt-text-muted"], [1, "svt-card-header-row"], ["name", "shield", 3, "size"], [1, "svt-form-col"], [3, "toggleChange", "checked", "label"], [1, "svt-text-hint"], [1, "svt-text-error", 2, "margin-top", "8px"]], template: function DiscordAutomodComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card");
            i0.ɵɵtemplate(1, DiscordAutomodComponent_ng_template_1_Template, 5, 4, "ng-template", 0);
            i0.ɵɵelementStart(2, "p", 1);
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(5, DiscordAutomodComponent_Conditional_5_Template, 3, 3, "p", 1)(6, DiscordAutomodComponent_Conditional_6_Template, 17, 22);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.automod.description"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.loading() ? 5 : ctx.cfg() ? 6 : -1);
        } }, dependencies: [CommonModule,
            SvtCardComponent,
            SvtCardHeaderDirective,
            SvtIconComponent,
            SvtToggleComponent,
            LocalizePipe], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordAutomodComponent, [{
        type: Component,
        args: [{
                selector: 'svt-discord-automod',
                standalone: true,
                imports: [
                    CommonModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtButtonComponent,
                    SvtIconComponent,
                    SvtToggleComponent,
                    LocalizePipe,
                ],
                template: `
    <svt-card>
      <ng-template svtCardHeader>
        <div class="svt-card-header-row">
          <svt-icon name="shield" [size]="18"/>
          <span>{{ 'discord.automod.title' | localize }}</span>
        </div>
      </ng-template>

      <p class="svt-text-muted">{{ 'discord.automod.description' | localize }}</p>

      @if (loading()) {
        <p class="svt-text-muted">{{ 'common.loading' | localize }}</p>
      } @else if (cfg()) {
        <div class="svt-form-col">
          <svt-toggle
            [checked]="cfg()!.linkFilter"
            [label]="'discord.automod.linkFilter' | localize"
            (toggleChange)="toggle('linkFilter', $event)"
          />
          <p class="svt-text-hint">{{ 'discord.automod.linkFilterHint' | localize }}</p>

          <svt-toggle
            [checked]="cfg()!.spamFilter"
            [label]="'discord.automod.spamFilter' | localize"
            (toggleChange)="toggle('spamFilter', $event)"
          />
          <p class="svt-text-hint">{{ 'discord.automod.spamFilterHint' | localize }}</p>

          <svt-toggle
            [checked]="cfg()!.mentionSpam"
            [label]="'discord.automod.mentionSpam' | localize"
            (toggleChange)="toggle('mentionSpam', $event)"
          />
          <p class="svt-text-hint">{{ 'discord.automod.mentionSpamHint' | localize }}</p>
        </div>

        @if (errorMsg()) {
          <p class="svt-text-error" style="margin-top:8px">{{ errorMsg() }}</p>
        }
      }
    </svt-card>
  `,
            }]
    }], null, { clientId: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordAutomodComponent, { className: "DiscordAutomodComponent", filePath: "lib/components/discord-automod.component.ts", lineNumber: 71 }); })();

const _c0 = () => ({ standalone: true });
const _forTrack0 = ($index, $item) => $item._id;
function DiscordGiveawaysComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵelement(1, "svt-icon", 3);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "localize");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 18);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.giveaways.title"));
} }
function DiscordGiveawaysComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 1);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "common.loading"));
} }
function DiscordGiveawaysComponent_Conditional_6_Conditional_0_For_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 12)(1, "div")(2, "strong");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span", 4);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "localize");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(7, "svt-button", 13);
    i0.ɵɵlistener("click", function DiscordGiveawaysComponent_Conditional_6_Conditional_0_For_4_Template_svt_button_click_7_listener() { const g_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r3.deleteGiveaway(g_r3._id)); });
    i0.ɵɵelement(8, "svt-icon", 14);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const g_r3 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(g_r3.prize);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate3(" ", " \u2014 ", "", g_r3.entrantUserIds.length, " ", i0.ɵɵpipeBind1(6, 6, "discord.giveaways.entrants"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("loading", ctx_r3.deleting() === g_r3._id);
    i0.ɵɵadvance();
    i0.ɵɵproperty("size", 14);
} }
function DiscordGiveawaysComponent_Conditional_6_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h4", 6);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵrepeaterCreate(3, DiscordGiveawaysComponent_Conditional_6_Conditional_0_For_4_Template, 9, 8, "div", 12, _forTrack0);
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "discord.giveaways.active"));
    i0.ɵɵadvance(2);
    i0.ɵɵrepeater(ctx_r3.activeGiveaways());
} }
function DiscordGiveawaysComponent_Conditional_6_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 4);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "localize");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "discord.giveaways.noActive"));
} }
function DiscordGiveawaysComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵconditionalCreate(0, DiscordGiveawaysComponent_Conditional_6_Conditional_0_Template, 5, 3)(1, DiscordGiveawaysComponent_Conditional_6_Conditional_1_Template, 3, 3, "p", 4);
    i0.ɵɵelementStart(2, "div", 5)(3, "h4", 6);
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "localize");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "svt-select", 7);
    i0.ɵɵpipe(7, "localize");
    i0.ɵɵlistener("onSelect", function DiscordGiveawaysComponent_Conditional_6_Template_svt_select_onSelect_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.newChannelId.set(($event == null ? null : $event.value) ?? "")); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "svt-input", 8);
    i0.ɵɵpipe(9, "localize");
    i0.ɵɵpipe(10, "localize");
    i0.ɵɵlistener("valueChange", function DiscordGiveawaysComponent_Conditional_6_Template_svt_input_valueChange_8_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.newPrize.set($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "svt-select", 7);
    i0.ɵɵpipe(12, "localize");
    i0.ɵɵlistener("onSelect", function DiscordGiveawaysComponent_Conditional_6_Template_svt_select_onSelect_11_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.newDuration.set(($event == null ? null : $event.value) ?? "86400000")); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "svt-input", 9);
    i0.ɵɵpipe(14, "localize");
    i0.ɵɵlistener("valueChange", function DiscordGiveawaysComponent_Conditional_6_Template_svt_input_valueChange_13_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onWinnerCountChange($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(15, "div", 10)(16, "svt-button", 11);
    i0.ɵɵlistener("click", function DiscordGiveawaysComponent_Conditional_6_Template_svt_button_click_16_listener() { i0.ɵɵrestoreView(_r1); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.createGiveaway()); });
    i0.ɵɵtext(17);
    i0.ɵɵpipe(18, "localize");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵconditional(ctx_r3.activeGiveaways().length > 0 ? 0 : 1);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 19, "discord.giveaways.create"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(7, 21, "discord.giveaways.channel"))("options", ctx_r3.textChannelOptions())("ngModel", ctx_r3.selectedChannelOption())("ngModelOptions", i0.ɵɵpureFunction0(33, _c0));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(9, 23, "discord.giveaways.prize"))("ngModel", ctx_r3.newPrize())("ngModelOptions", i0.ɵɵpureFunction0(34, _c0))("placeholder", i0.ɵɵpipeBind1(10, 25, "discord.giveaways.prizePlaceholder"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(12, 27, "discord.giveaways.duration"))("options", ctx_r3.durationOptions)("ngModel", ctx_r3.selectedDurationOption())("ngModelOptions", i0.ɵɵpureFunction0(35, _c0));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("label", i0.ɵɵpipeBind1(14, 29, "discord.giveaways.winnerCount"))("ngModel", ctx_r3.newWinnerCount())("ngModelOptions", i0.ɵɵpureFunction0(36, _c0));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("loading", ctx_r3.creating());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(18, 31, ctx_r3.creating() ? "common.saving" : "discord.giveaways.start"), " ");
} }
const DURATION_OPTIONS = [
    { value: '3600000', label: '1 hour' },
    { value: '21600000', label: '6 hours' },
    { value: '86400000', label: '24 hours' },
    { value: '259200000', label: '3 days' },
    { value: '604800000', label: '7 days' },
];
class DiscordGiveawaysComponent {
    constructor() {
        this.port = inject(DISCORD_DATA_PORT);
        this.i18n = inject(TRANSLATE_PORT);
        this.toastr = inject(NOTIFICATION_PORT);
        this.t = (k) => this.i18n.translate(k);
        this.clientId = '';
        this.channels = [];
        this.hostUserId = '';
        this.durationOptions = DURATION_OPTIONS;
        this.loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
        this.creating = signal(false, ...(ngDevMode ? [{ debugName: "creating" }] : []));
        this.deleting = signal(null, ...(ngDevMode ? [{ debugName: "deleting" }] : []));
        this._giveaways = signal([], ...(ngDevMode ? [{ debugName: "_giveaways" }] : []));
        this.activeGiveaways = computed(() => this._giveaways().filter(g => !g.ended), ...(ngDevMode ? [{ debugName: "activeGiveaways" }] : []));
        this.newChannelId = signal('', ...(ngDevMode ? [{ debugName: "newChannelId" }] : []));
        this.newPrize = signal('', ...(ngDevMode ? [{ debugName: "newPrize" }] : []));
        this.newDuration = signal('86400000', ...(ngDevMode ? [{ debugName: "newDuration" }] : []));
        this.newWinnerCount = signal(1, ...(ngDevMode ? [{ debugName: "newWinnerCount" }] : []));
        this.textChannelOptions = computed(() => this.channels.filter(c => c.type === 0).map(c => ({ value: c.id, label: `#${c.name}` })), ...(ngDevMode ? [{ debugName: "textChannelOptions" }] : []));
        this.selectedChannelOption = computed(() => this.textChannelOptions().find(o => o.value === this.newChannelId()) ?? null, ...(ngDevMode ? [{ debugName: "selectedChannelOption" }] : []));
        this.selectedDurationOption = computed(() => this.durationOptions.find(o => o.value === this.newDuration()) ?? null, ...(ngDevMode ? [{ debugName: "selectedDurationOption" }] : []));
    }
    onWinnerCountChange(val) {
        const n = parseInt(val, 10);
        this.newWinnerCount.set(n > 0 ? n : 1);
    }
    ngOnChanges() {
        if (this.clientId)
            this.load();
    }
    load() {
        this.loading.set(true);
        this.port.getGiveaways(this.clientId).subscribe({
            next: g => { this._giveaways.set(g); this.loading.set(false); },
            error: () => this.loading.set(false),
        });
    }
    createGiveaway() {
        if (!this.newChannelId() || !this.newPrize() || this.creating())
            return;
        this.creating.set(true);
        this.port.createGiveaway(this.clientId, {
            channelId: this.newChannelId(),
            prize: this.newPrize(),
            durationMs: +this.newDuration(),
            winnerCount: this.newWinnerCount(),
            hostUserId: this.hostUserId,
        }).subscribe({
            next: res => {
                this.creating.set(false);
                this._giveaways.set([res.giveaway, ...this._giveaways()]);
                this.newPrize.set('');
                this.toastr.success(this.t('common.success'), this.t('discord.giveaways.created'));
            },
            error: () => {
                this.creating.set(false);
                this.toastr.error(this.t('common.error'), this.t('discord.giveaways.createFailed'));
            },
        });
    }
    deleteGiveaway(giveawayId) {
        if (this.deleting())
            return;
        this.deleting.set(giveawayId);
        this.port.deleteGiveaway(this.clientId, giveawayId).subscribe({
            next: () => {
                this.deleting.set(null);
                this._giveaways.set(this._giveaways().filter(g => g._id !== giveawayId));
                this.toastr.success(this.t('common.success'), this.t('discord.giveaways.deleted'));
            },
            error: () => {
                this.deleting.set(null);
                this.toastr.error(this.t('common.error'), this.t('discord.giveaways.deleteFailed'));
            },
        });
    }
    static { this.ɵfac = function DiscordGiveawaysComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DiscordGiveawaysComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DiscordGiveawaysComponent, selectors: [["svt-discord-giveaways"]], inputs: { clientId: "clientId", channels: "channels", hostUserId: "hostUserId" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 4, consts: [["svtCardHeader", ""], [1, "svt-text-muted"], [1, "svt-card-header-row"], ["name", "gift", 3, "size"], [1, "svt-text-muted", "svt-text-sm"], [1, "svt-form-section", 2, "margin-top", "16px"], [1, "svt-label"], [3, "onSelect", "label", "options", "ngModel", "ngModelOptions"], [3, "valueChange", "label", "ngModel", "ngModelOptions", "placeholder"], ["type", "number", 2, "width", "80px", 3, "valueChange", "label", "ngModel", "ngModelOptions"], [1, "svt-form-actions"], ["variant", "primary", 3, "click", "loading"], [1, "svt-panel-row"], ["variant", "ghost", "size", "small", 3, "click", "loading"], ["name", "x", 3, "size"]], template: function DiscordGiveawaysComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "svt-card");
            i0.ɵɵtemplate(1, DiscordGiveawaysComponent_ng_template_1_Template, 5, 4, "ng-template", 0);
            i0.ɵɵelementStart(2, "p", 1);
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "localize");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(5, DiscordGiveawaysComponent_Conditional_5_Template, 3, 3, "p", 1)(6, DiscordGiveawaysComponent_Conditional_6_Template, 19, 37);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "discord.giveaways.description"));
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.loading() ? 5 : 6);
        } }, dependencies: [CommonModule,
            FormsModule, i1.NgControlStatus, i1.NgModel, SvtCardComponent,
            SvtCardHeaderDirective,
            SvtButtonComponent,
            SvtInputComponent,
            SvtIconComponent,
            SvtSelectComponent,
            LocalizePipe], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DiscordGiveawaysComponent, [{
        type: Component,
        args: [{
                selector: 'svt-discord-giveaways',
                standalone: true,
                imports: [
                    CommonModule,
                    FormsModule,
                    SvtCardComponent,
                    SvtCardHeaderDirective,
                    SvtButtonComponent,
                    SvtInputComponent,
                    SvtIconComponent,
                    SvtSelectComponent,
                    LocalizePipe,
                ],
                template: `
    <svt-card>
      <ng-template svtCardHeader>
        <div class="svt-card-header-row">
          <svt-icon name="gift" [size]="18"/>
          <span>{{ 'discord.giveaways.title' | localize }}</span>
        </div>
      </ng-template>

      <p class="svt-text-muted">{{ 'discord.giveaways.description' | localize }}</p>

      @if (loading()) {
        <p class="svt-text-muted">{{ 'common.loading' | localize }}</p>
      } @else {
        <!-- Active giveaways list -->
        @if (activeGiveaways().length > 0) {
          <h4 class="svt-label">{{ 'discord.giveaways.active' | localize }}</h4>
          @for (g of activeGiveaways(); track g._id) {
            <div class="svt-panel-row">
              <div>
                <strong>{{ g.prize }}</strong>
                <span class="svt-text-muted svt-text-sm">
                  {{ ' — ' }}{{ g.entrantUserIds.length }} {{ 'discord.giveaways.entrants' | localize }}
                </span>
              </div>
              <svt-button variant="ghost" size="small" [loading]="deleting() === g._id" (click)="deleteGiveaway(g._id)">
                <svt-icon name="x" [size]="14"/>
              </svt-button>
            </div>
          }
        } @else {
          <p class="svt-text-muted svt-text-sm">{{ 'discord.giveaways.noActive' | localize }}</p>
        }

        <!-- Create giveaway form -->
        <div class="svt-form-section" style="margin-top:16px">
          <h4 class="svt-label">{{ 'discord.giveaways.create' | localize }}</h4>
          <svt-select
            [label]="'discord.giveaways.channel' | localize"
            [options]="textChannelOptions()"
            [ngModel]="selectedChannelOption()"
            [ngModelOptions]="{ standalone: true }"
            (onSelect)="newChannelId.set($event?.value ?? '')"
          />
          <svt-input
            [label]="'discord.giveaways.prize' | localize"
            [ngModel]="newPrize()"
            [ngModelOptions]="{ standalone: true }"
            (valueChange)="newPrize.set($event)"
            [placeholder]="'discord.giveaways.prizePlaceholder' | localize"
          />
          <svt-select
            [label]="'discord.giveaways.duration' | localize"
            [options]="durationOptions"
            [ngModel]="selectedDurationOption()"
            [ngModelOptions]="{ standalone: true }"
            (onSelect)="newDuration.set($event?.value ?? '86400000')"
          />
          <svt-input
            [label]="'discord.giveaways.winnerCount' | localize"
            type="number"
            [ngModel]="newWinnerCount()"
            [ngModelOptions]="{ standalone: true }"
            (valueChange)="onWinnerCountChange($event)"
            style="width:80px"
          />
          <div class="svt-form-actions">
            <svt-button variant="primary" [loading]="creating()" (click)="createGiveaway()">
              {{ (creating() ? 'common.saving' : 'discord.giveaways.start') | localize }}
            </svt-button>
          </div>
        </div>
      }
    </svt-card>
  `,
            }]
    }], null, { clientId: [{
            type: Input
        }], channels: [{
            type: Input
        }], hostUserId: [{
            type: Input
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DiscordGiveawaysComponent, { className: "DiscordGiveawaysComponent", filePath: "lib/components/discord-giveaways.component.ts", lineNumber: 116 }); })();

/*
 * Public API Surface of @servitium/discord
 *
 * Shared Discord management feature components + the ports each host app binds
 * to its own services. Used by center.servitium.org and discord.servitium.org.
 */
// Ports (each app provides an implementation)

/**
 * Generated bundle index. Do not edit.
 */

export { DISCORD_DATA_PORT, DiscordAutomodComponent, DiscordGiveawaysComponent, DiscordGreetingComponent, DiscordLevelingComponent, DiscordReactionRolesComponent, DiscordStatsComponent, DiscordVoiceHubsComponent, DiscordWelcomeComponent, LocalizePipe, NOTIFICATION_PORT, TRANSLATE_PORT };
//# sourceMappingURL=servitium-discord.mjs.map
